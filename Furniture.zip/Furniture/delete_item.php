<?php
    include 'admin_check_login.php';
    $cat_id = $_GET['cid'];
    $item_id = $_GET['iid'];

    if(isset($_POST['del_item']))
    {
        $sql = "DELETE FROM `category_items` WHERE `category_id` = '$cat_id' AND `item_id` = '$item_id'";
        $result = mysqli_query($conn , $sql);
    }

    header("location:/furniture/category_admin.php?ano=".$admin_id."&cid=".$cat_id."");


?>