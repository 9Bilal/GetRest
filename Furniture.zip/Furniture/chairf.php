<?php
  include 'dbconnect.php';
?>

<html><head>
    <title>Chairs</title>
  
  
  
    <link rel="stylesheet" href="css.css">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  
  </head>
  <body>
  <script src="js.js"></script>
      
  
  
  <div class="background1">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
          <li><a href="homef.php" target="_self" style="color: black;">Home</a></li>
            <li><a href="Aboutf.php" target="_self"style="color: black;">About</a></li>
            <li><a href="productf.php" target="_self"style="color: black;">Product</a></li>
            <li><a href="cartf.php" target="_self"style="color: black;">Cart</a></li>
            <li> <a href="#" target="_self"style="color: black;">Categories</a>
              <!-- Dropdown content -->
              <div class="dropdown-content">
                <a href="bedf.php"style="color: black;">BED</a>
                <a href="sofaf.php"style="color: black;">SOFA</a>
                <a href="kidsf.php"style="color: black;">KIDS</a>
                <a href="chairf.php"style="color: black;">CHAIR</a>
              </div>
            </li>
            <li><a href="contactf.php" target="_self"style="color: black;">Contact us</a></li>
            
          </ul>
        </nav>
      </table>
    </p>
    </header>
    <p class="headertext">
        <center><p style="color: white;font-size: 40px;">CHAIR</p></center>
    </p>
  </div>







<br><br>

<h2 style="color: #007D69;">CUSTOMER FAVOURITES</h2>

<br><br><br><br>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="chair1.jpg" alt="chair1" width="220px" height="213px">
      <p style="margin-top: 5%;">
        Hayward Lounge Chair</p>
      <h5 style="color: #007D69;">Rs 18,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="chair2a.jpg" alt="chair2a" width="220px" height="213px">
      <p style="margin-top: 5%;">Modern Chair</p>
      <h5 style="color: #007D69;">Rs 40,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="chair3.jpg" alt="chair3" width="220px" height="213px">
      <p style="margin-top: 5%;">Boucle Occasional Chair</p>
      <h5 style="color: #007D69;">Rs 22,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="chair4.jpg" alt="chair4" width="220px" height="213px">
      <p style="margin-top: 5%;">Helen Considered Chair</p>
      <h5 style="color: #007D69;">Rs 10,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>
</div>
<br><br><br><br>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="chair5a.jpg" alt="chair5" width="220px" height="213px">
      <p style="margin-top: 5%;">Clingy Lover Chair</p>
      <h5 style="color: #007D69;">Rs 10,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="chair6.jpeg" alt="chair6" width="220px" height="213px">
      <p style="margin-top: 5%;">Cream Velvet Accent Chair 
        </p>
      <h5 style="color: #007D69;">Rs 15,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="chair7.jpg" alt="chair7" width="220px" height="213px">
      <p style="margin-top: 5%;">Christopher Club Chair</p>
      <h5 style="color: #007D69;">Rs 20,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="chair8.jpg" alt="chair8" width="220px" height="213px">
      <p style="margin-top: 5%;">Reading Chair</p>
      <h5 style="color: #007D69;">Rs 13,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>
</div>


<br><br><br><br>

<!-- footer -->
<footer>
    <div class="row">
      <div class="col">
        <h2 style="color: #007D69;">GetRest</h2>
        <p>
          Ferozpur Road Lahore
          <br><br>
          haiderb811@gmail.com
          <br><br>
          03310155706
        </p>
      </div>
      <div style="margin-left: %;">
    <div class="col"> 
     <h2>Office</h2>
     <p>Ferozpur Road</p>
     <p>Kalma Chowk, Lahore</p>
     <p>54600, Pakistan</p>
     <p class="email-id">haiderb811@gmail.com</p>
     <h4>+92 - 03310155706</h4>
  
    </div>
  </div>
  
    <div class="col">
      <h2>Links</h2>
      
      <ul>
      <li><a href="homef.php">Home</a></li>
       <li><a href="Aboutf.php">About</a></li>
        <li><a href="productf.php">Product </a></li>
        <li><a href="cartf.php">Cart </a></li>
        <li><a href="contactf.php">Contact </a></li>
      </ul>
    </div>
  
    <div class="col">
  <h2>NewsLette</h2>
  <form>
    <div class="footer-section">
    <form action="#" method="post">
      <input type="email" name="email" placeholder="Your Email" style="color: black;">
      <button type="submit">Subscribe</button>
  </form>
  
    </div>
    
    </div>