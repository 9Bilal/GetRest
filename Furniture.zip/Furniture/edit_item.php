<?php
  include 'dbconnect.php';
  include 'admin_check_login.php';
  $category_id = $_GET['cid'];
  $item_id     = $_GET['iid'];

  if(isset($_POST['change']))
  {
    $area = $_POST['area'];
    $new_val = $_POST['new_val'];

    if(!empty($area) && !empty($new_val))
    {
      $sql = "UPDATE `category_items` SET `$area` = '$new_val' WHERE `category_id` = '$category_id' AND `item_id` = '$item_id'";
      $result = mysqli_query($conn , $sql);
      if($result)
      {
        header("location:/furniture/category_admin.php?ano=".$admin_id."&cid=".$category_id."&iid=".$item_id."");
      }
    }
  }
?>

<html><head>
    <title>Admin</title>
  
  
  
    <link rel="stylesheet" href="css.css">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
 <style>
.itemcon1 {
border: 2px solid #007D69;
 width: 300px;
 height: 430px;
  margin-top:70px;
  margin-right:1120px;
}

.itemcon12 {
 border: 2px solid #007D69;
 width: 300px;
 height: 170px;
 margin-left: 39%;
 margin-top: 5%;
}
.itemcon12 input{
  margin-left:0%;
  border:1px solid black;
  color:black;
  width:50%;
}
.itemcon12 button{
  border:1px solid black;
  color:black;
  height:30px;
  width:100px;
  font-size:13px;
}

.main12{
  width:90%;
  margin:auto;
  position:relative;
  top:-20px;
  height:<?php if($row<=4){echo'5px;';}else{echo'150px;';} ?>;
}
.cat1{
  border:1px solid #007D69;
  width:200px;
  height:80px;
  float:left;
  /* padding:30px; */
  margin-left:68px;
  margin-bottom:30px;
}

.cat1 h1{
  text-align:center;
  margin-top:7px;
}

.cat1 button{
  margin-top:6px;
  
}

.categorydelete1 {
  border: 1px solid #007D69;
  width: 200px;
 height: 80px;
 margin-left: 5%;
 
}

.categorydelete2 {
  border: 1px solid #007D69;
  width: 200px;
 height: 80px;
 margin-left: 29%;
 margin-top: -6.2%;
 
}

.categorydelete3 {
  border: 1px solid #007D69;
  width: 200px;
 height: 80px;
 margin-left: 55%;
 margin-top: -6.2%;
}

.categorydelete4 {
  border: 1px solid #007D69;
  width: 200px;
 height: 80px;
 margin-left: 80%;
 margin-top: -6.2%;
}

.dropdown-content1 {
  display: none;
  position: absolute;
  background-color: #e2e1e1;
  box-shadow: 0 4px 1px rgba(173, 107, 107, 0.1);
  z-index: 1;
  margin-left: 16%;
}
.dropdown-content1 a {
  display: block;
  padding: 9px;
  color: #007D69;
}


/* Show dropdown on hover */
nav li:hover .dropdown-content1 {
  display: block;
}
</style>

  
  </head>
  <body>
  <script src="js.js"></script>
      
  
  
  <div class="background1">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
            <li><a href="admin_furniture.php" target="_self"style="color: black;">Add New Category</a></li>
            

            <li> <a href="category_admin.php" target="_self"style="color: black;">Categories</a>
              <!-- Dropdown content -->
              <div class="dropdown-content1">
                  <?php
                    $sql = "SELECT * FROM `category`";
                    $result = mysqli_query($conn , $sql);
                    while($data = mysqli_fetch_assoc($result))
                    {
                      $category_id = $data['category_id'];
                      $category_name = $data['category_name'];
                      echo '<a href="category_admin.php?cid='.$category_id.'&ano='.$admin_id.'" style="color: black;">'.$category_name.'</a>';
                    }
                  
              echo'<li><a href="order.php?ano='.$admin_id.'" target="_self"style="color: black;">Orders</a></li>';?>
              </div>
            </li>
            
            
            <?php echo'<li><a href="multiple.php?ano='.$admin_id.'" target="_self"style="color: black;">multiple item orders</a></li>';?>
            <li><a href="admin_logout.php" target="_self"style="color: black;">Logout</a></li>
          </ul>
        </nav>
      </table>
    </p>
    </header>
    <p class="headertext">
        <center><p style="color: white;font-size: 40px;">Admin</p></center>
    </p>
  </div>


  <div class="itemcon12">
    <br>
    <h3 style="margin-left: 26%;">Edit Item Category</h3><br>
    <?php echo'<form action="/furniture/edit_item.php?ano='.$admin_id.'&cid='.$category_id.'&iid='.$item_id.'" method="post">';?>
        
          <select id="" name="area" required style="width: 50%;">
              <option value=""></option>
              <option value="item_name">Name</option>
              <option value="item_price">Price</option>
          </select><br>
          <input type="text" id="new_val" name="new_val"><br> 
          <button type="submit" name="change">Confirm</button>
          
      </div>
      
    </form>
  </div>
<br><br><br>