<?php

  include 'dbconnect.php';
  $user_email = $user_pass = "";

  $null = false;
  if(isset($_POST['login']))
  {
    if(empty($_POST['user_email']))
    {
      $null = true;
    }
    else
    {
      $user_email = $_POST['user_email'];
    }

    if(empty($_POST['user_pass']))
    {
      $null = true;
    }
    else
    {
      $user_pass = $_POST['user_pass'];
    }

    if($null == false)
    {
      $sql = "SELECT * FROM `users` WHERE `user_email` = '$user_email'";
      $result = mysqli_query($conn , $sql);
      $row = mysqli_num_rows($result);
      if($row>=1)
      {
        $data = mysqli_fetch_assoc($result);
          $password = $data['user_pass'];
          if($user_pass == $password)
          {
            $user_id = $data['user_id'];
            $login = true;
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION["user_id"] = $user_id;
            header("location:/furniture/user_homef.php?uno=".$user_id."");
          }
      }
      else
      {
        $sql = "SELECT * FROM `admin` WHERE `admin_email` = '$user_email'";
        $result = mysqli_query($conn , $sql);
        $row = mysqli_num_rows($result);
        if($row>=1)
        {
          $data = mysqli_fetch_assoc($result);
          $admin_pass = $data['admin_pass'];
          if($user_pass == $admin_pass)
          {
            $admin_id = $data['admin_id'];
            $login = true;
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION["admin_id"] = $admin_id;
            header("location:/furniture/admin_furniture.php?ano=".$admin_id."");
          }
        }
      }
    }
  }

?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>login</title>
  <link rel="stylesheet" href="css_login.css">

</head>
<body>

<div class="wrapper">
      <div class="title-text">
        <div class="title login">Login Form</div>
        <div class="title signup">Signup Form</div>
      </div>
      <div class="form-container">
        <div class="slide-controls">
          <input type="radio" name="slide" id="login" checked>
          <input type="radio" name="slide" id="signup">
          <label for="login" class="slide login">Login</label>
          <label for="signup" class="slide signup">Signup</label>
          <div class="slider-tab"></div>
        </div>
        <div class="form-inner">

          <form action="/furniture/loginf.php" class="login" method="post">
            <div class="field">
              <input type="email" name="user_email" placeholder="Email Address" required>
            </div>
            <div class="field">
              <input type="password" name="user_pass" placeholder="Password" required>
            </div>
            <div class="pass-link"><a href="Forgot.php">Forgot password?</a></div>
            <div class="field btn">
              <div class="btn-layer"></div>
              <input type="submit" name="login" value="Login">
            </div>
            <div class="signup-link">Not a member? <a href="">Signup now</a></div>
          </form>

          <form action="/furniture/signup.php" class="signup" method="post">
            <div class="field">
              <input type="email" name="user_email" placeholder="Email Address" required>
            </div>
            <div class="field">
              <input type="password" name="user_pass" placeholder="Password" required>
            </div>
            <div class="field">
              <input type="password" name="user_confirm_pass" placeholder="Confirm password" required>
            </div>
            <div class="field btn">
              <div class="btn-layer"></div>
              <input type="submit" name="signup" value="Signup">
            </div>
          </form>
        </div>
      </div>
    </div>

  <script  src="js.js"></script>

</body>
</html>
