<?php
  include 'dbconnect.php';
  include 'user_check_login.php';

?>

<html><head>
    <title>Contact</title>
  
  
  
    <link rel="stylesheet" href="css.css">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  
  </head>
  <body>
  <script src="js.js"></script>
      
  
  
  <div class="background1">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
          <li>
            <?php echo'<a href="user_homef.php?uno='.$user_id.'" target="_self" style="color: black;">Home</a></li>
            <li><a href="user_Aboutf.php?uno='.$user_id.'" target="_self"style="color: black;">About</a></li>
            <li><a href="user_productf.php?uno='.$user_id.'" target="_self"style="color: black;">Product</a></li>
            <li><a href="user_cartf.php?uno='.$user_id.'" target="_self"style="color: black;">Cart</a></li>
            <li> <a href="#" target="_self"style="color: black;">Categories</a>
              <!-- Dropdown content -->
              <div class="dropdown-content">';?>
                  <?php
                    $sql = "SELECT * FROM `category`";
                    $result = mysqli_query($conn , $sql);
                    while($data = mysqli_fetch_assoc($result))
                    {
                      $category_id = $data['category_id'];
                      $category_name = $data['category_name'];
                      echo '<a href="user_category.php?cid='.$category_id.'&uno='.$user_id.'" style="color: black;">'.$category_name.'</a>';
                    }
                  ?>
              </div>
            </li>
            <?php echo'<li><a href="user_contactf.php?uno='.$user_id.'" target="_self" style="color: black;">Contact us</a></li>
                <li><a href="user_logout.php?uno='.$user_id.'" target="_self" style="color: black;">Logout</a></li>';?>
          </ul>
        </nav>
      </table>
    </p>
    </header>
    <p class="headertext">
        <center><p style="color: white;font-size: 40px;">CONTACT US</p></center>
    </p>
  </div>




  <br><br>
<center>
<h1 style="color: #007D69;">
Our Outlet Address!Please Visit Us.
</h1>
</center>

<h3 style="margin-left: 20%; margin-top: 5%;">
  
  <span>&#8226;<b>Lahore Shop</b>
</h3></span>
  <p style="margin-left: 20%; margin-top: 1%;">
    T Plaza Kalma Chowk Lahore
  </p>
  <p style="margin-left: 20%; margin-top: 1%;">
    <b>Call Us</b> 03001100011
  </p>
  <br>
  <p style="margin-left: 20%; margin-top: 1%;">
    Timing Monday-Friday
  </p>
  <p style="margin-left: 20%; margin-top: 1%;">
    9 am To 8 pm
  </p>



  <h3 style="margin-left: 45%; margin-top: -13%;">
  
    <span>&#8226;<b>Karachi Shop</b>
  </h3></span>
  <p style="margin-left: 45%; margin-top: 1%;">
    F Plaza PAF Museum Karachi
  </p>
  <p style="margin-left: 45%; margin-top: 1%;">
    <b>Call Us</b> 03001100011
  </p>
  <br>
  <p style="margin-left: 45%; margin-top: 1%;">
    Timing Monday-Saturday
  </p>
  <p style="margin-left: 45%; margin-top: 1%;">
    9 am To 8 pm
  </p>


  <h3 style="margin-left: 70%; margin-top: -13%;">
  
    <span>&#8226;<b>Multan Shop</b>
  </h3></span>
  <p style="margin-left: 70%; margin-top: 1%;">
    B Plaza Ghanta Ghar Multan
  </p>
  <p style="margin-left: 70%; margin-top: 1%;">
    <b>Call Us</b> 03001101010
  </p>
  <br>
  <p style="margin-left: 70%; margin-top: 1%;">
    Timing Monday-Saturday
  </p>
  <p style="margin-left: 70%; margin-top: 1%;">
    9 am To 7 pm
  </p>

<br><br><br><br>
<center>
  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14160545.787458412!2d58.34370577044854!3d29.945946656027527!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38db52d2f8fd751f%3A0x46b7a1f7e614925c!2sPakistan!5e0!3m2!1sen!2s!4v1685627385410!5m2!1sen!2s" width="1050" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade "></iframe>
</center>



<br><br><br>
<center>
<h1 style="color: #007D69;"> Ask Us Anything Here</h1>
</center>

<br><br><br>
<center>
<h1 style="color: #007D69;"> Ask Us Anything Here</h1>
</center><br><br>
<form action="submit_form.php" method="post">
  <div class="container123">
      <div class="left">
          <label for="name">Name:</label>
          <input type="name" id="name" name="name" required style="color: black; " >

          <label for="email">Email:</label>
          <input type="email" id="email" name="email" required style="color: black;">

          <label for="city">City:</label>
          <select id="city" name="city" required>
              <option value="">Select City</option>
              <option value="lahore">Lahore</option>
              <option value="karachi">Karachi</option>
              <option value="multan">Multan</option>
          </select>
      </div>
      <div class="right">
          <label for="message">Message:</label>
          <textarea id="message" name="message" rows="4" required></textarea>
      </div>
  </div><br><br>
  <input type="submit" value="Send Now" style="width: 10%;">
</form>








<style>
.float{
	position:fixed;
	width:60px;
	height:60px;
	bottom:20px;
	right:15px;
	background-color:#25d366;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}

.my-float{
	margin-top:16px;
} 
</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<a href="https://api.whatsapp.com/send?phone=+923310155706&text=GetRest How Can i Help You" class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>
<!-- footer -->
<footer>
  <div class="row">
    <div class="col">
      <h2 style="color: #007D69;">GetRest</h2>
      <p>
        Ferozpur Road Lahore
        <br><br>
        haiderb811@gmail.com
        <br><br>
        03310155706
      </p>
    </div>
    <div style="margin-left: %;">
  <div class="col"> 
   <h2>Office</h2>
   <p>Ferozpur Road</p>
   <p>Kalma Chowk, Lahore</p>
   <p>54600, Pakistan</p>
   <p class="email-id">haiderb811@gmail.com</p>
   <h4>+92 - 03310155706</h4>

  </div>
</div>

  <div class="col">
    <h2>Links</h2>
    
    <ul>
    
    <?php echo'<li><a href="user_homef.php?uno='.$user_id.'" target="_self">Home</a></li>';?>
    <?php echo'<li><a href="user_Aboutf.php?uno='.$user_id.'" target="_self">About</a></li>';?>
    <?php echo'<li><a href="user_productf.php?uno='.$user_id.'" target="_self">Product</a></li>';?>
    <?php echo'<li><a href="user_cartf.php?uno='.$user_id.'">Cart </a></li>';?>
    
    <?php echo'<li><a href="user_contactf.php?uno='.$user_id.'">Contact us</a></li>';?>
    
  </ul>
  </div>

  <div class="col">
<h2>NewsLette</h2>
<form>
  <div class="footer-section">
  <form action="#" method="post">
    <input type="email" name="email" placeholder="Your Email" style="color: black;">
    <button type="submit">Subscribe</button>
</form>

  </div>
  
  </div>