
<?php
  include 'dbconnect.php';
  include 'admin_check_login.php';
?>

<html><head>
    <title>Order</title>
  
  
  
    <link rel="stylesheet" href="css.css">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
 <style>
.itemcon1 {
border: 2px solid #007D69;
 width: 300px;
 height: 430px;
  margin-top:70px;
  margin-right:1120px;
}

.itemcon12 {
 border: 2px solid #007D69;
 width: 300px;
 height: 170px;
 margin-left: 39%;
 margin-top: 5%;
}

.main12{
  width:90%;
  margin:auto;
  position:relative;
  top:-20px;
  height:<?php if($row<=4){echo'5px;';}else{echo'150px;';} ?>;
}
.cat1{
  border:1px solid #007D69;
  width:200px;
  height:80px;
  float:left;
  /* padding:30px; */
  margin-left:68px;
  margin-bottom:30px;
}

.cat1 h1{
  text-align:center;
  margin-top:7px;
}

.cat1 button{
  margin-top:6px;
  
}

.categorydelete1 {
  border: 1px solid #007D69;
  width: 200px;
 height: 80px;
 margin-left: 5%;
 
}

.categorydelete2 {
  border: 1px solid #007D69;
  width: 200px;
 height: 80px;
 margin-left: 29%;
 margin-top: -6.2%;
 
}

.categorydelete3 {
  border: 1px solid #007D69;
  width: 200px;
 height: 80px;
 margin-left: 55%;
 margin-top: -6.2%;
}

.categorydelete4 {
  border: 1px solid #007D69;
  width: 200px;
 height: 80px;
 margin-left: 80%;
 margin-top: -6.2%;
}

.dropdown-content1 {
  display: none;
  position: absolute;
  background-color: #e2e1e1;
  box-shadow: 0 4px 1px rgba(173, 107, 107, 0.1);
  z-index: 1;
  margin-left: 16%;
}
.dropdown-content1 a {
  display: block;
  padding: 9px;
  color: #007D69;
}


/* Show dropdown on hover */
nav li:hover .dropdown-content1 {
  display: block;
}
</style>

  
  </head>
  <body>
  <script src="js.js"></script>
      
  
  
  <div class="background1">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
            <?php echo'<li><a href="admin_furniture.php?ano='.$admin_id.'" target="_self"style="color: black;">Add New Category</a></li>';?>
            

            <?php echo'<li> <a href="category_admin.php?cid=1&ano='.$admin_id.'" target="_self"style="color: black;">Categories</a>';?>
              <!-- Dropdown content -->
              <div class="dropdown-content1">
                  <?php
                    $sql = "SELECT * FROM `category`";
                    $result = mysqli_query($conn , $sql);
                    while($data = mysqli_fetch_assoc($result))
                    {
                      $category_id = $data['category_id'];
                      $category_name = $data['category_name'];
                      echo '<a href="category_admin.php?cid='.$category_id.'&ano='.$admin_id.'" style="color: black;">'.$category_name.'</a>';
                    }
                  
              echo'<li><a href="order.php?ano='.$admin_id.'" target="_self"style="color: black;">Orders</a></li>';?>
              </div>
            </li>
            
           
            <?php echo'<li><a href="multiple.php?ano='.$admin_id.'" target="_self"style="color: black;">multiple item orders</a></li>';?>
            <?php echo'<li><a href="admin_logout.php?ano='.$admin_id.'" target="_self"style="color: black;">Logout</a></li>';?>
          </ul>
        </nav>
      </table>
    </p>
    </header>
    <p class="headertext">
        <center><p style="color: white;font-size: 40px;">Admin</p></center>
    </p>
  </div>



<body>
    <center><h1>ORDERS</h1>
    <?php
        $sql = "SELECT * FROM `orders` WHERE `price`!=''";
        $result = mysqli_query($conn , $sql);
        $row = mysqli_num_rows($result);
        if($row>=1)
        {
            while($data=mysqli_fetch_assoc($result))
            {
                $name = $data['name'];
                $city = $data['city'];
                $zip  = $data['zip'];
                $address = $data['address'];
                $price = $data['price'];
                $description = $data['description'];
                $comment = $data['comment'];
                $id = $data['id'];

                $cat_id = $data['cat_id'];
                $item_id = $data['item_id'];

                // $sql1 = "SELECT * FROM `category_items` WHERE `category_id` = '$cat_id' AND `item_id` = '$item_id'";
                // $result1 = mysqli_query($conn , $sql1);
                // $data_ = mysqli_fetch_assoc($result1);
                // $item_name = $data_['item_name'];
                // $item_pic = $data_['item_pic'];
                $sql1 = "SELECT * FROM `category_items` WHERE `category_id` = '$cat_id' AND `item_id` = '$item_id'";
                $result1 = mysqli_query($conn, $sql1);
                
                if ($result1) {
                    $data_ = mysqli_fetch_assoc($result1);
                    
                    if ($data_) {
                        $item_name = $data_['item_name'];
                        $item_pic = $data_['item_pic'];
                        
                        // Further processing with $item_name and $item_pic
                    } else {
                        // Handle case where no row was found
                        $item_name = null;
                        $item_pic = null;
                    }
                } else {
                    // Handle SQL query error
                    echo "Error: " . mysqli_error($conn);
                }



                echo '<h3>Address</h3>
                <p>Name : '.$name.'</p>
                <p>CITY : '.$city.'</p>
                <p>ZIP : '.$zip.'</p>
                <p>ADDRESS : '.$address.'</p>
                <p>COMMENT : '.$comment.'</p><br>
                <h2>Order</h2>
                <p>ITEM NAME : '.$item_name.' </p>
                <p>ITEM PRICE : '.$price.'</p>
                <p>ITEM DESCRIPTION : '.$description.'</p>
                <form action="/furniture/order_done.php?ano='.$admin_id.'&oid='.$id.'" method="post"><br>
                    <button type="submit" name="done" style="color: #007D69;"><b>DONE</b></button>
                </form>
                <br><br><hr><br>';

            }
        }

    ?></center>
</body>
</html>
