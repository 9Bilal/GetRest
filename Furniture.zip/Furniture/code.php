<?php
  include 'dbconnect.php';
  $user_id = $_GET['uno'];
  $type = $_GET['type'];


  if(isset($_POST['submit']))
  {
    $code = $_POST['number'];
    if($type == "admin")
    {
      $sql = "SELECT * FROM `admin` WHERE `admin_id` = '$user_id' AND `verification` = '$code'";
      $result = mysqli_query($conn , $sql);
      $row = mysqli_num_rows($result);
      if($row>=1)
      {
        $sql = "UPDATE `admin` SET `verification` = ''";
        $result = mysqli_query($conn , $sql);
        header("location:/furniture/change_password.php?uno=".$user_id."&type=admin");
      }
    }
    else
    if($type == "users")
    {
      $sql = "SELECT * FROM `users` WHERE `user_id` = '$user_id' AND `verification` = '$code'";
      $result = mysqli_query($conn , $sql);
      $row = mysqli_num_rows($result);
      if($row>=1)
      {
        $sql = "UPDATE `users` SET `verification` = ''";
        $result = mysqli_query($conn , $sql);
        header("location:/furniture/change_password.php?uno=".$user_id."&type=users");
      }
    }

  }
  

?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Verification</title>
  <link rel="stylesheet" href="css_login.css">
<style>

.code22 {
margin-left: 39%;
margin-top: 2%;

}


.forgotsubmitbtn {
  margin-left: 44%;
  margin-top: 1%;
  
}
 



</style>
</head>

<body>
<h1 style="margin-left: 40%; margin-top: 4%; color: #007D69;">Verification</h1>
<?php echo'<form action="/furniture/code.php?uno='.$user_id.'&type='.$type.'" method="post">';?>
<div class="code22">
<input type="number" name="number" style="width: 27%;" required>
</div>
<div class="forgotsubmitbtn">
    <input type="submit" name="submit" value="submit" style="width: 10%;">
</form>
</div>
</body>
</html>