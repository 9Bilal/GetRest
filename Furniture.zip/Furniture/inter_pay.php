<?php
session_start();
require('config.php'); // Include your Stripe configuration file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get POST data and store in session
    $_SESSION['order_details'] = [
        'name' => $_POST['name'],
        'cell' => $_POST['cell'],
        'address' => $_POST['address'],
        'items' => $_POST['items']
    ];

    // Decode JSON string to array and check for validity
    $items = isset($_POST['items']) ? json_decode($_POST['items'], true) : [];

    if (json_last_error() !== JSON_ERROR_NONE) {
        die('Invalid JSON data');
    }

    // Calculate total amount from items
    $total_amount = 0;
    foreach ($items as $item) {
        $total_amount += $item['price'] * $item['quantity'];
    }
    $_SESSION['total_amount'] = $total_amount * 100; // Stripe amount is in cents
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment Page</title>
</head>
<body>
    <form action="sub2.php" method="post">
        <script
            src="https://checkout.stripe.com/checkout.js" class="stripe-button" 
            data-key="<?php echo $publishableKey ?>"
            data-amount="<?php echo $_SESSION['total_amount']; ?>"
            data-name="GetRest"
            data-description="Payment Method"
            data-image=""
            data-currency="PKR"
            data-email="user@gmail.com"
        ></script>
    </form>
</body>
</html>
