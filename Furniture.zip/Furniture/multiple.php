<?php
include 'dbconnect.php'; // Include your database connection file
include 'admin_check_login.php';

// Fetch all unique order numbers
$sql_orders = "SELECT DISTINCT order_number, name, cell_number, address FROM orderadmin ORDER BY order_date DESC";
$result_orders = mysqli_query($conn, $sql_orders);

if (!$result_orders) {
    die("Query Failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Orders</title>
    <link rel="stylesheet" href="styles.css"> <!-- Assuming you have a styles.css file -->
</head>
<body>
    <h1>All Orders</h1>

    <?php
    if (mysqli_num_rows($result_orders) > 0) {
        while ($order = mysqli_fetch_assoc($result_orders)) {
            $order_number = $order['order_number'];
            $name = $order['name'];
            $cell_number = $order['cell_number'];
            $address = $order['address'];

            // Fetch all items for this order
            $sql_items = "SELECT * FROM orderadmin WHERE order_number = '$order_number'";
            $result_items = mysqli_query($conn, $sql_items);

            if (!$result_items) {
                die("Query Failed: " . mysqli_error($conn));
            }

            $total_price = 0;
            ?>
            <h2>Order Number: <?php echo htmlspecialchars($order_number); ?></h2>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($name); ?></p>
            <p><strong>Contact Number:</strong> <?php echo htmlspecialchars($cell_number); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($address); ?></p>
            <table border="1">
                <tr>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Price per Item</th>
                    <th>Subtotal</th>
                </tr>
                <?php
                while ($item = mysqli_fetch_assoc($result_items)) {
                    $total_price += $item['subtotal'];
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                        <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                        <td><?php echo 'RS ' . number_format($item['price'], 2); ?></td>
                        <td><?php echo 'RS ' . number_format($item['subtotal'], 2); ?></td>
                    </tr>
                    <?php
                }
                ?>
                <tr>
                    <td colspan="3"><strong>Total Price</strong></td>
                    <td><strong><?php echo 'RS ' . number_format($total_price, 2); ?></strong></td>
                </tr>
            </table>
            <br><br>
            <?php
        }
    } else {
        echo "<p>No orders found.</p>";
    }

    // Close database connection
    mysqli_close($conn);
    ?>
</body>
</html>
