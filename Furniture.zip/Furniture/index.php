<?php
require('config.php');
?>
<form action="submit.php" method="post">
    <script
        src="https://checkout.stripe.com/checkout.js" class="stripe-button" 
        data-key="<?php echo $publishableKey?>"
        data-amount="50000"
        data-name="GetRest"
        data-description="Payment Method"
        data-image=""
        data-currency="PKR"
        data-address=""  
    >

    </script>
</form>