<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add to Cart</title>
    <script>
    function addToCart() {
        alert("Item added to cart successfully!");
        return true; // Allow the form to submit
    }
    </script>
</head>
<body>
    <form id="add-to-cart-form" method="post" action="add_to_cart.php?cid=<?php echo $cat_id; ?>&iid=<?php echo $item_id; ?>" onsubmit="return addToCart();">
        <button type="submit" name="add">Add to Cart</button>
    </form>
</body>
</html>

<?php
include "user_check_login.php";

$cat_id  = $_GET['cid'];
$item_id = $_GET['iid'];

if(isset($_POST['add'])) {
    $sql = "SELECT * FROM `cart` WHERE `category_id` = '$cat_id' AND `item_id` = '$item_id' AND `user_id` = '$user_id'";
    $result = mysqli_query($conn , $sql);

    if(!$result) {
        die("Query failed: " . mysqli_error($conn));
    }

    $row = mysqli_num_rows($result);

    if($row <= 0) {
        $sql = "SELECT * FROM `category_items` WHERE `category_id` = '$cat_id' AND `item_id` = '$item_id'";
        $result = mysqli_query($conn , $sql);

        if(!$result) {
            die("Query failed: " . mysqli_error($conn));
        }

        $data = mysqli_fetch_assoc($result);
        if($data) {
            $item_name = mysqli_real_escape_string($conn, $data['item_name']);
            $item_price = $data['item_price'];
            $item_pic = mysqli_real_escape_string($conn, $data['item_pic']);
            $item_desc = mysqli_real_escape_string($conn, $data['item_desc']);

            $sqll = "INSERT INTO `cart` (`user_id`, `item_id`, `category_id`, `item_name`, `item_price`, `item_pic`, `item_desc`, `quantity`)
                     VALUES ('$user_id', '$item_id', '$cat_id', '$item_name', '$item_price', '$item_pic', '$item_desc', 1)";
            $result = mysqli_query($conn , $sqll);

            if(!$result) {
                die("Query failed: " . mysqli_error($conn));
            }
        } else {
            echo "Item not found in the specified category.";
            exit();
        }
    } else {
        echo "Item is already in the cart.";
        exit();
    }
}

header("location:/furniture/user_category.php?cid=".$cat_id."&uno=".$user_id."");
?>
