<?php
    include 'dbconnect.php';
    $user_id = $_GET['uno'];
    session_start();
    if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
    {
        header("location:/furniture/homef.php");
        exit;
    }
    else{
        $user = $_SESSION['user_id'];
        if($user != $user_id)
        {
            unset($_SESSION['user_id']);
            session_destroy();
            header("location:/furniture/homef.php");
            exit;
        }
        else
        {
            $sql = "SELECT * FROM `users` WHERE `user_id` = '$user_id'";
            $result = mysqli_query($conn , $sql);
            $row = mysqli_num_rows($result);
            if($row == 0)
            {
                unset($_SESSION['user_id']);
                session_destroy();
                header("location:/furniture/homef.php");
            }
        }
    }

?>