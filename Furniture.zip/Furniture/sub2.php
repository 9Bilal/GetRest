<?php
include 'dbconnect.php'; // Include your database connection file
require_once('config.php'); // Include your Stripe configuration
include 'user_check_login.php';

$sql = "SELECT * FROM `users` WHERE `user_id` = '$user_id'";
    $result = mysqli_query($conn , $sql);
    $data = mysqli_fetch_assoc($result);
    $mail = $data['user_email'];

// Retrieve order number from URL parameter
$order_number = $_GET['order_number'];

// Fetch order details from database based on order number
$sql = "SELECT * FROM orderadmin WHERE order_number = '$order_number'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // Initialize variables
    $items = [];
    $totalAmount = 0;

    // Fetch items and calculate total amount
    while ($row = mysqli_fetch_assoc($result)) {
        $item_name = $row['item_name'];
        $quantity = $row['quantity'];
        $price = $row['price'];
        $subtotal = $row['subtotal'];

        // Build items array for Stripe Checkout
        $items[] = [
            'name' => $item_name,
            'quantity' => $quantity,
            'price' => $price,
            'subtotal' => $subtotal,
        ];

        // Calculate total amount
        $totalAmount += $subtotal;
    }
} else {
    echo "No order found.";
    exit();
}
?>

<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <link rel="stylesheet" href="css.css">
    <script src="js.js"></script>
</head>
<body>
    <center>
    <h1>Payment Details</h1>

    <!-- Display order summary or details -->
    <p>Order Number: <?php echo $order_number; ?></p>
    <p>Order Total: PKR <?php echo number_format($totalAmount, 2); ?></p>
    </center>
    <!-- Stripe Checkout button -->
    <form action="charge.php" method="POST">
        <script
            src="https://checkout.stripe.com/checkout.js" class="stripe-button"
            data-key="<?php echo $publishableKey; ?>"
            data-amount="<?php echo $totalAmount * 100; ?>"
            data-name="GetRest"
            data-description="Payment for Order <?php echo $order_number; ?>"
            data-currency="PKR"
            data-email="<?php echo $mail;?>"
        >
        </script>
        <input type="hidden" name="order_number" value="<?php echo $order_number; ?>">
    </form>
</body>
</html>

<?php
// Close database connection
mysqli_close($conn);
?>
