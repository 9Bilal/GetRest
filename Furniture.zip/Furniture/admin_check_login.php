<?php
    include 'dbconnect.php';
    $admin_id = $_GET['ano'];
    session_start();
    if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
    {
        header("location:/furniture/homef.php");
        exit;
    }
    else{
        $user_id = $_SESSION['admin_id'];
        if($user_id != $admin_id)
        {
            unset($_SESSION['admin_id']);
            session_destroy();
            header("location:/furniture/homef.php");
            exit;
        }
        else
        {
            $sql = "SELECT * FROM `admin` WHERE `admin_id` = '$admin_id'";
            $result = mysqli_query($conn , $sql);
            $row = mysqli_num_rows($result);
            if($row == 0)
            {
                unset($_SESSION['admin_id']);
                session_destroy();
                header("location:/furniture/homef.php");
            }
        }
    }

?>