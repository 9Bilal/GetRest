<?php
  include 'dbconnect.php';
?>

<html><head>
    <title>Sofa</title>
  
  
  
    <link rel="stylesheet" href="css.css">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  
  </head>
  <body>
  <script src="js.js"></script>
      
  
  
  <div class="background1">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
          <li><a href="homef.php" target="_self" style="color: black;">Home</a></li>
            <li><a href="Aboutf.php" target="_self"style="color: black;">About</a></li>
            <li><a href="productf.php" target="_self"style="color: black;">Product</a></li>
            <li><a href="cardf.php" target="_self"style="color: black;">Cart</a></li>
            <li> <a href="#" target="_self"style="color: black;">Categories</a>
              <!-- Dropdown content -->
              <div class="dropdown-content">
                <a href="bedf.php"style="color: black;">BED</a>
                <a href="sofaf.php"style="color: black;">SOFA</a>
                <a href="kidsf.php"style="color: black;">KIDS</a>
                <a href="chairf.php"style="color: black;">CHAIR</a>
              </div>
            </li>
            <li><a href="contactf.php" target="_self"style="color: black;">Contact us</a></li>
            
          </ul>
        </nav>
      </table>
    </p>
    </header>
    <p class="headertext">
        <center><p style="color: white;font-size: 40px;">SOFA</p></center>
    </p>
  </div>







<br><br>

<h2 style="color: #007D69;">CUSTOMER FAVOURITES</h2>

<br><br><br><br>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="sofa1.jpg" alt="sofa1" width="220px" height="213px">
      <p style="margin-top: 5%;">Introspect Modern Sofa</p>
      <h5 style="color: #007D69;">Rs 60,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="sofa2.jpg" alt="sofa2" width="220px" height="213px">
      <p style="margin-top: 5%;">Eden Sofa</p>
      <h5 style="color: #007D69;">Rs 70,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="sofa3.jpg" alt="sofa3" width="220px" height="213px">
      <p style="margin-top: 5%;">Apollo Combo Corner Sofa</p>
      <h5 style="color: #007D69;">Rs 99,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="soda4.jpg" alt="sofa4" width="220px" height="213px">
      <p style="margin-top: 5%;">U-Shape Sofa</p>
      <h5 style="color: #007D69;">Rs 150,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>
</div>
<br><br><br><br>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="sofa5.jpg" alt="sofa" width="220px" height="213px">
      <p style="margin-top: 5%;">Pebble Cream Fabric Sofa</p>
      <h5 style="color: #007D69;">Rs 99,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="sofa6.jfif" alt="sofa6" width="220px" height="213px">
      <p style="margin-top: 5%;"> 2 Seater Sofa Set</p>
      <h5 style="color: #007D69;">Rs 199,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="sofa7.jpg" alt="sofa7" width="220px" height="213px">
      <p style="margin-top: 5%;">Sight Unseen Wooden Sofa</p>
      <h5 style="color: #007D69;">Rs 50,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="sofa8.jpg" alt="sofa8" width="220px" height="213px">
      <p style="margin-top: 5%;">Wakefit Sofa</p>
      <h5 style="color: #007D69;">Rs 100,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>
</div>





<br><br><br><br>

<!-- footer -->
<footer>
  <div class="row">
    <div class="col">
      <h2 style="color: #007D69;">GetRest</h2>
      <p>
        Ferozpur Road Lahore
        <br><br>
        haiderb811@gmail.com
        <br><br>
        03310155706
      </p>
    </div>
    <div style="margin-left: %;">
  <div class="col"> 
   <h2>Office</h2>
   <p>Ferozpur Road</p>
   <p>Kalma Chowk, Lahore</p>
   <p>54600, Pakistan</p>
   <p class="email-id">haiderb811@gmail.com</p>
   <h4>+92 - 03310155706</h4>

  </div>
</div>

  <div class="col">
    <h2>Links</h2>
    
    <ul>
    <li><a href="homef.php">Home</a></li>
       <li><a href="Aboutf.php">About</a></li>
        <li><a href="productf.php">Product </a></li>
        <li><a href="cardf.php">Cart </a></li>
        <li><a href="contactf.php">Contact </a></li>
    </ul>
  </div>

  <div class="col">
<h2>NewsLette</h2>
<form>
  <div class="footer-section">
  <form action="#" method="post">
    <input type="email" name="email" placeholder="Your Email" style="color: black;">
    <button type="submit">Subscribe</button>
</form>

  </div>
  
  </div>