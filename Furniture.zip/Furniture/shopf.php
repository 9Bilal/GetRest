<?php
  include 'dbconnect.php';
?>


<html><head>
    <title>Shop</title>
  
  
  
    <link rel="stylesheet" href="css.css">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  
  </head>
  <body>
  <script src="js.js"></script>
      
  
  
  <div class="background1">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
            <li><a href="#" target="_self" style="color: black;">Home</a></li>
            <li><a href="#" target="_self"style="color: black;">About</a></li>
            <li><a href="#" target="_self"style="color: black;">Shop</a></li>
            <li><a href="#" target="_self"style="color: black;">Product</a></li>
            <li>
              <a href="#" target="_self"style="color: black;">Categories</a>
              <!-- Dropdown content -->
              <div class="dropdown-content">
                <a href="#"style="color: black;">BED</a>
                <a href="#"style="color: black;">SOFA</a>
                <a href="#"style="color: black;">KIDS</a>
                <a href="#"style="color: black;">CHAIR</a>
              </div>
            </li>
            <li><a href="#" target="_self"style="color: black;">Contact us</a></li>
            
          </ul>
        </nav>
      </table>
    </p>
    </header>
    <p class="headertext">
        <center><p style="color: white;font-size: 40px;">SHOP</p></center>
    </p>










<br><br><br><br><br><br><br><br><br>
    
<!-- footer -->
<footer>
  <div class="row">
    <div class="col">
      <h2 style="color: #007D69;">GetRest</h2>
      <p>
        Ferozpur Road Lahore
        <br><br>
        haiderb811@gmail.com
        <br><br>
        03310155706
      </p>
    </div>
    <div style="margin-left: %;">
  <div class="col"> 
   <h2>Office</h2>
   <p>Ferozpur Road</p>
   <p>Kalma Chowk, Lahore</p>
   <p>54600, Pakistan</p>
   <p class="email-id">haiderb811@gmail.com</p>
   <h4>+92 - 03310155706</h4>

  </div>
</div>

  <div class="col">
    <h2>Links</h2>
    
    <ul>
     <li><a href="home.html">Home</a></li>
     <li><a href="Blood About.html">About</a></li>
      <li><a href="gallery.html">Shop</a></li>
      <li><a href="contact.html">Product </a></li>
      <li><a href="Campaign.html">Categories </a></li>
      <li><a href="Campaign.html">Contact </a></li>
    </ul>
  </div>

  <div class="col">
<h2>NewsLette</h2>
<form>
  <div class="footer-section">
  <form action="#" method="post">
    <input type="email" name="email" placeholder="Your Email" style="color: black;">
    <button type="submit">Subscribe</button>
</form>
<div class="social-icons"><br>
  <a href="https://www.facebook.com/"> <i class="fab fa-facebook"></i></a>
  <a href="https://www.twitter.com/"><i class="fab fa-twitter"></i></a>
  <a href="https://www.whatsapp.com/"><i class="fab fa-whatsapp"></i></a>
  <a href="https://www.pinterest.com/"><i class="fab fa-pinterest"></i></a>
</div>
  </div>
  
  </div>
  <hr>