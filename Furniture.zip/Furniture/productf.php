<?php
  include 'dbconnect.php';
?>

<html><head>
  <title>Products</title>

  <link rel="stylesheet" href="css.css">

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">


</head>
<body>
<script src="js.js"></script>
    


<div class="background1">
 
<header>

  <div class="logo1">
          
      <p>
          </p><h2>
              GetRest
          </h2>
      <p></p>
    </div>
    <!-- Update class names in the HTML -->
    <p class="aboutheader">
    <table class="nav-table">
      <nav>
        <ul>
          <li><a href="homef.php" target="_self" style="color: black;">Home</a></li>
          <li><a href="Aboutf.php" target="_self"style="color: black;">About</a></li>
          <li><a href="productf.php" target="_self"style="color: black;">Product</a></li>
          <li><a href="loginf.php" target="_self"style="color: black;">Card</a></li>
          <li> <a href="#" target="_self"style="color: black;">Categories</a>
            <!-- Dropdown content -->
            <div class="dropdown-content">
              
            <?php
            $sql = "SELECT * FROM `category`";
            $result = mysqli_query($conn , $sql);
            while($data = mysqli_fetch_assoc($result))
            {
              $category_id = $data['category_id'];
              $category_name = $data['category_name'];
              echo '<a href="category.php?cid='.$category_id.'" style="color: black;">'.$category_name.'</a>';
            }
            ?>
            </div>
          </li>
          <li><a href="contactf.php" target="_self"style="color: black;">Contact us</a></li>
          
        </ul>
      </nav>
    </table>
  </p>
  </header>
  <p class="headertext">
      <center><p style="color: white;font-size: 40px;">PRODUCTS</p></center>
  </p>
</div>




<br><br>

<h2 style="color: #007D69;">CUSTOMER FAVOURITES</h2>

<br><br><br><br>
<div class="row">
  <?php
    $sql = "SELECT * FROM `category_items`";
    $result = mysqli_query($conn , $sql);
    while($data = mysqli_fetch_assoc($result))
    {
      $cat_id = $data['category_id'];
      $item_id = $data['item_id'];
      $item_name = $data['item_name'];
      $item_price = $data['item_price'];
      $item_pic = $data['item_pic'];

      echo '<div class="column" style="margin-bottom:40px;">
      <a href="/furniture/per-product.php?cid='.$cat_id.'&iid='.$item_id.'"><div class="card">
          <img src="'.$item_pic.'" alt="bed7" width="220px" height="213px">
          <p style="font-size:16px;margin-top: 5%;">'.$item_name.'</p>
          <h6 style="color: #007D69;">Rs '.$item_price.'</h6>
          <br>
          <form action="/furniture/add_to_cart.php?cid='.$cat_id.'&iid='.$item_id.'" method="post">
            <button type="submit" name="add" class="button" style="width:160px;">Add to Cart</submit>
          </form>
      </div></a>
    </div>'; 
}
?>
  
</div>


  


  






<br><br><br><br>

<style>
.float{
	position:fixed;
	width:60px;
	height:60px;
	bottom:20px;
	right:15px;
	background-color:#25d366;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}

.my-float{
	margin-top:16px;
} 
</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<a href="https://api.whatsapp.com/send?phone=+923310155706&text=GetRest How Can i Help You" class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>
<!-- footer -->
<footer>
<div class="row">
  <div class="col">
    <h2 style="color: #007D69;">GetRest</h2>
    <p>
      Ferozpur Road Lahore
      <br><br>
      haiderb811@gmail.com
      <br><br>
      03310155706
    </p>
  </div>
  <div style="margin-left: %;">
<div class="col"> 
 <h2>Office</h2>
 <p>Ferzpur Road</p>
 <p>Kalma Chowk, Lahore</p>
 <p>54600, Pakistan</p>
 <p class="email-id">haiderb811@gmail.com</p>
 <h4>+92 - 03310155706</h4>

</div>
</div>

<div class="col">
  <h2>Links</h2>
  
  <ul>
  <li><a href="homef.php">Home</a></li>
       <li><a href="Aboutf.php">About</a></li>
        <li><a href="productf.php">Product </a></li>
        <li><a href="cardf.php">Card </a></li>
        <li><a href="contactf.php">Contact </a></li>
  </ul>
</div>

<div class="col">
<h2>NewsLette</h2>
<form>
<div class="footer-section">
<form action="#" method="post">
  <input type="email" name="email" placeholder="Your Email" style="color: black;">
  <button type="submit">Subscribe</button>
</form>

</div>

</div>

       