<?php
require('config.php');
include 'user_check_login.php';
$cat_id = $_GET['cid'];
$item_id = $_GET['iid'];
$quantity = $_GET['q'];
$user_id = $_GET['uno'];

$sql = "SELECT * FROM `category_items` WHERE `item_id` = '$item_id' AND `category_id` = '$cat_id'";
$result = mysqli_query($conn , $sql);
$row = mysqli_num_rows($result);
if($row>=1)
{
    $data1 = mysqli_fetch_assoc($result);
    $item_price = $data1['item_price'];
    $item_description = $data1['item_desc'];

    \Stripe\Stripe::setVerifySslCerts(false);

    $token=$_POST['stripeToken'];

    $data=\Stripe\Charge::create(array(
        "amount"=>$item_price * 100,
        "currency"=>"PKR",
        "description"=>"Payment Method",
        "source"=>$token,   
        
    ));

    $item_price = $item_price * $quantity;
    $sql = "UPDATE `orders` SET `price`='$item_price' , `description`='$item_description' WHERE 
    `user_id` = '$user_id' AND `cat_id` = '$cat_id' AND `item_id` = '$item_id'";
    $result = mysqli_query($conn , $sql);
}

header("location:/furniture/user_category.php?uno=".$user_id."&cid=".$cat_id."&iid=".$item_id."");



?>