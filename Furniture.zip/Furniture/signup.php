<?php
    include 'dbconnect.php';

    $user_email = $user_pass = $user_confirm_pass = "";
    $null = false;

    if(isset($_POST['signup']))
    {
        if(empty($_POST['user_email']))
        {
            $null = true;
        }
        else
        {
            $user_email = $_POST['user_email'];
        }

        if(empty($_POST['user_pass']))
        {
            $null = true;
        }
        else
        {
            $user_pass = $_POST['user_pass'];
        }

        if(empty($_POST['user_confirm_pass']))
        {
            $null = true;
        }
        else
        {
            $user_confirm_pass = $_POST['user_confirm_pass'];
        }

        if($null == false)
        {
            $sql = "SELECT * FROM `users` WHERE `user_email` = '$user_email'";
            $result = mysqli_query($conn , $sql);
            $row = mysqli_num_rows($result);
            if($row<=0)
            {
                if($user_pass == $user_confirm_pass)
                {
                    $sql = "INSERT INTO `users` (`user_email` , `user_pass` , `timestamp`,`verification`) VALUES
                    ('$user_email' , '$user_pass' , current_timestamp(),'')";
                    $result = mysqli_query($conn , $sql);
                }
            }
        }
    }

    header("location:/furniture/loginf.php");


?>