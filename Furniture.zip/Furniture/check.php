<?php
include 'dbconnect.php'; // Include your database connection file
include 'user_check_login.php';


// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get POST data
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $cell_number = mysqli_real_escape_string($conn, $_POST['cell']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $order_number = 'ORD-' . strtoupper(uniqid());

    // Decode JSON string to array
    $items = isset($_POST['items']) ? json_decode($_POST['items'], true) : [];

    // Loop through cart items and insert into database
    foreach ($items as $item) {
        $itemName = mysqli_real_escape_string($conn, $item['name']);
        $quantity = intval($item['quantity']);
        $price = floatval($item['price']);
        $subtotal = floatval($item['subtotal']);

        $sql = "INSERT INTO orderadmin(order_number, name, cell_number, address, item_name, quantity, price, subtotal)
                VALUES ('$order_number', '$name', '$cell_number', '$address', '$itemName', $quantity, $price, $subtotal)";

        if (!mysqli_query($conn, $sql)) {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }

    // Close database connection
    mysqli_close($conn);

    // Redirect to payment page or show success message
    header("Location: sub2.php?uno=".$user_id."&order_number=" . urlencode($order_number));
    exit();
}
?>

<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Page</title>
    <link rel="stylesheet" href="css.css">
</head>
<body>
    <form action="check.php" method="POST">
        NAME: <input type="text" name="name" required><br>
        CELL: <input type="text" name="cell" required><br>
        ADDRESS: <input type="text" name="address" required><br>

        <!-- Example items JSON array structure -->
        <input type="hidden" name="items" value='<?php echo json_encode($items); ?>'>

        <button type="submit">Place Order</button>
    </form>
</body>
</html>
