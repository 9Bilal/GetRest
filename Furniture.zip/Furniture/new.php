<?php
require('config.php');

// Example variables (replace with actual values)
$user_id = 123; // Example user ID
$cat_id = 456; // Example category ID
$item_id = 789; // Example item ID
$price = 1000; // Example item price

// Check if the buy action is triggered (example condition)
$buy = true;

if ($buy && $_SERVER["REQUEST_METHOD"] == "POST") {
    // Token is created using Checkout or Elements!
    // Get the payment token ID submitted by the form:
    $token = $_POST['stripeToken'];

    try {
        // Create a Charge:
        $charge = \Stripe\Charge::create([
            'amount' => $price * 100, // Amount in cents
            'currency' => 'PKR',
            'description' => 'Payment for item purchase',
            'source' => $token,
        ]);

        // If successful, update your database or perform other actions
        // Example: Update order status, save charge ID, etc.

        // Redirect to a success page or do further processing
        header("Location: payment_success.php");
        exit();
    } catch (\Stripe\Exception\CardException $e) {
        // Since it's a decline, \Stripe\Exception\CardException will be caught
        $error = $e->getError()->message;
    } catch (\Stripe\Exception\RateLimitException $e) {
        // Too many requests made to the API too quickly
        $error = $e->getError()->message;
    } catch (\Stripe\Exception\InvalidRequestException $e) {
        // Invalid parameters were supplied to Stripe's API
        $error = $e->getError()->message;
    } catch (\Stripe\Exception\AuthenticationException $e) {
        // Authentication with Stripe's API failed
        $error = $e->getError()->message;
    } catch (\Stripe\Exception\ApiConnectionException $e) {
        // Network communication with Stripe failed
        $error = $e->getError()->message;
    } catch (\Stripe\Exception\ApiErrorException $e) {
        // Display a very generic error to the user, and maybe send
        // yourself an email
        $error = $e->getError()->message;
    } catch (Exception $e) {
        // Something else happened, completely unrelated to Stripe
        $error = $e->getMessage();
    }
}
?>

<!-- Display the payment form -->
<form action="" method="post">
    <script
            src="https://checkout.stripe.com/checkout.js" class="stripe-button"
            data-key="your_publishable_api_key_here"
            data-amount="<?php echo $price * 100; ?>" <!-- Amount in cents -->
            data-name="GetRest"
            data-description="Payment for item purchase"
            data-image=""
            data-currency="PKR"
            data-email="user@gmail.com">
    </script>
</form>
