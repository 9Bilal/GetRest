<?php
    include 'user_check_login.php';

    $cat_id  = $_GET['cid'];
    $item_id = $_GET['iid'];

    if(isset($_POST['remove']))
    {
        $sql = "DELETE FROM `cart` WHERE `category_id` = '$cat_id' AND `item_id` = '$item_id' AND `user_id` = '$user_id'";
        $result = mysqli_query($conn , $sql);
    }

    header("location:/furniture/user_cartf.php?uno=".$user_id."");

?>