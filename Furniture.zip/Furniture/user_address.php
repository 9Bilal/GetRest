<?php
    require ('config.php');
    include 'user_check_login.php';
    $cat_id = $_GET['cid'];
    $item_id = $_GET['iid']; 
    $quantity = $_GET['q'];
    $comment = $_GET['comment'];

    $sql = "SELECT * FROM `users` WHERE `user_id` = '$user_id'";
    $result = mysqli_query($conn , $sql);
    $data = mysqli_fetch_assoc($result);
    $mail = $data['user_email'];

    $sql = "SELECT * FROM `category_items` WHERE `item_id` = '$item_id' AND `category_id` = '$cat_id'";
    $result = mysqli_query($conn , $sql);
    $data = mysqli_fetch_assoc($result);
    $price = $data['item_price'];
    $description = $data['item_desc'];

    $buy = false;
    if(isset($_POST['add_address']))
    {
        $name = $_POST['name'];
        $city = $_POST['city'];
        $zip  = $_POST['zip'];
        $address = $_POST['address'];

        $sql = "INSERT INTO `orders` (`name`,`city`,`zip`,`address`,`user_id`,`cat_id`,`item_id`,`price`,`description`,`fabric`,`polish`,`comment`)
        VALUES('$name','$city','$zip','$address','$user_id','$cat_id','$item_id','','','','','$comment')";
        $result = mysqli_query($conn , $sql);
        if($result)
        {
            $buy = true;

        }
    }

?>

<html><head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

  
  
  
    <link rel="stylesheet" href="css.css">
  
    <style>
 .form24{
  width: 20%;
  padding: 14px 16px;
  
 }


      </style>
  
  </head>
  <body>
  <script src="js.js"></script>
  
  <div class="background1">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
          <li>
            <?php echo'<a href="user_homef.php?uno='.$user_id.'" target="_self" style="color: black;">Home</a></li>
            <li><a href="user_Aboutf.php?uno='.$user_id.'" target="_self"style="color: black;">About</a></li>
            <li><a href="user_productf.php?uno='.$user_id.'" target="_self"style="color: black;">Product</a></li>
            <li><a href="user_cartf.php?uno='.$user_id.'" target="_self"style="color: black;">Cart</a></li>
            <li> <a href="#" target="_self"style="color: black;">Categories</a>
              <!-- Dropdown content -->
              <div class="dropdown-content">';?>
                  <?php
                    $sql = "SELECT * FROM `category`";
                    $result = mysqli_query($conn , $sql);
                    while($data = mysqli_fetch_assoc($result))
                    {
                      $category_id = $data['category_id'];
                      $category_name = $data['category_name'];
                      echo '<a href="user_category.php?cid='.$category_id.'&uno='.$user_id.'" style="color: black;">'.$category_name.'</a>';
                    }
                  ?>
              </div>
            </li>
            
            <?php echo'<li><a href="user_contactf.php?uno='.$user_id.'" target="_self" style="color: black;">Contact us</a></li>
                <li><a href="user_logout.php?uno='.$user_id.'" target="_self" style="color: black;">Logout</a></li>';?>
          </ul>
        </nav>
      </table>
    </p>
    </header>
    <p class="headertext">
        <center><p style="color: white;font-size: 40px;">ADDRESS</p></center>
    </p>
  </div>
            
  <br><br><br><br><br><br>

<body>
  <center>
    <h1>USER ADDRESS</h1>
    <div class="form24">
    <?php echo'<form action="/furniture/user_address.php?uno='.$user_id.'&cid='.$cat_id.'&iid='.$item_id.'&q=1&comment='.$comment.'" method="post">';?>
    
    NAME : <input type="text" name="name" required style="color: black; border: 1px solid #000;"><br>
        CITY : <input type="text" name="city"  required style="color: black; border: 1px solid #000;"><br>
        ZIP  : <input type="text" name="zip" required style="color: black; border: 1px solid #000;"><br>
        ADDRESS : <input type="text" name="address" required style="color: black; border: 1px solid #000;"><br>
        <input type="submit" name="add_address" style="width: 60%;">
    </form></div>
                  </center>
    <?php
        if($buy == true)
        {
            echo'<form action="submit.php?uno='.$user_id.'&cid='.$cat_id.'&iid='.$item_id.'&q=1" method="post">';?> 
        <script
        src="https://checkout.stripe.com/checkout.js" class="stripe-button" 
        data-key="<?php echo $publishableKey?>"
        data-amount="<?php echo $price * 100?>"
        data-name="GetRest"
        data-description="Payment Method"
        data-image=""
        data-currency="PKR"
        data-email = "<?php echo $mail;?>"
    >
 <?php
 echo'
    </script>';
        }

    ?>
</body>
</html>




