<?php
    include 'dbconnect.php';
    include 'user_check_login.php';
    session_start();
    unset($_SESSION['user_id']);
    session_destroy();
    header("location:/furniture/homef.php");
    exit();

?>
