<?php

require('stripe-php-master/init.php');
$publishableKey="pk_test_51PCa0vK3jbGnkyl13lTJlNvIuNC7fX9Dn8WYM3Ab3k4AZgY8rjMhySHTvTjngNv4qtmiyzLpRJ4vKy7GjWwDtADF00zSVNqNCi";

$secretKey="sk_test_51PCa0vK3jbGnkyl1nbUnNeLKvH2hHKRkaNorsZhWdrMVHXcmBGpEB21eC0ekTVdAG8WiDOx7ZIqOVrFBCjmVnF0O00wtruSCBE";
\Stripe\Stripe::setApiKey($secretKey);

?>