<?php
  include 'dbconnect.php';
  include 'user_check_login.php';
?>

<html><head>
  <title>Furnitures</title>



  <link rel="stylesheet" href="css.css">

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">


</head>
<body>
<script src="js.js"></script>
    <div class="background">



<header>
         
          <div class="logo">
            
            <p>
                </p><h2>
                    GetRest
                </h2>
            <p></p>
          </div>
          <table class="nav-table">
            <nav>
              <ul>
                <?php echo'<li><a href="user_homef.php?uno='.$user_id.'" target="_self">Home</a></li>';?>
                <?php echo'<li><a href="user_Aboutf.php?uno='.$user_id.'" target="_self">About</a></li>';?>
                <?php echo'<li><a href="user_productf.php?uno='.$user_id.'" target="_self">Product</a></li>';?>
                <?php echo'<li><a href="user_cartf.php?uno='.$user_id.'">Cart </a></li>';?>
                <li><a href="#" target="_self">Categories</a>
                  <!-- Dropdown content -->
                  <div class="dropdown-content">
                  <?php
                    $sql = "SELECT * FROM `category`";
                    $result = mysqli_query($conn , $sql);
                    while($data = mysqli_fetch_assoc($result))
                    {
                      $category_id = $data['category_id'];
                      $category_name = $data['category_name'];
                      echo '<a href="user_category.php?cid='.$category_id.'&uno='.$user_id.'" style="color: black;">'.$category_name.'</a>';
                    }
                  ?>
                  </div>
                </li>
                <?php echo'<li><a href="user_contactf.php?uno='.$user_id.'" target="_self">Contact us</a></li>
                <li><a href="user_logout.php?uno='.$user_id.'" target="_self">Logout</a></li>';?>
              </ul>
            </nav>
          </table>
        </header>
        
        <br><br><br>  
        
        

<div class="background1">
  <div class="transbox">
    <p>
      <h1 class="text1">
        <font size="+6.5" </font>
  
          Discover the <br>Best Furnitures
      </h1>

      <p class="text2">
        <font size="+1.5" </font>
        Custom-made furniture allows you to choose the<br> materials, finishes, and designs tailored to your specific <br>needs and preferences
      </p>
      
      <?php echo'<a href="user_productf.php?uno='.$user_id.'" class="shop-button">Shop Now</a></p>';?>
      <div class="playtriangle">
        <div class="play-button">
          <div class="triangle"></div></div>
          <p class="watchvideo">
          <a href="Cousins Furniture Promotional Video.mp4" target="_self" style="text-decoration: none;color: white;">Watch Video</a></p>
    
        </div>
  </div>
</div>

       
<br><br><br><br><br>

        <p class="image">
          <img src="chair.png" alt="chair" width="520px" height="360px">
        </p>
       
      <!.............................Header close...................................>

        <br><br><br><br>

<h1 class="text3">
  What We Do
</h1>
<p class="text4">
  Welcome to our GetRest furniture haven! At our website, we strive to offer more<br> than just pieces of furniture; we provide a gateway to comfort, style, and functionality<br> for your living spaces. Our carefully curated collection boasts a diverse range of designs,<br> from modern minimalist to timeless classics, ensuring that there's something to suit every taste<br> and preference.
</p>

<br>
<p class="learnbutton">

<?php echo'<a href="user_Aboutf.php?uno='.$user_id.'" style="text-decoration: none;color: white;">Learn More</a>';?>
</p>
   
<br><br><br>
<div class="container221">
<div class="container22">
  <img src="yellow.jpg" alt="yellow" class="left-image">
  
  <div class="text-content">
      <h1>Design Award 2024 Now<br> Open For Intries</h1>
      <p>In navigating the furniture market in Pakistan, several considerations can help in avoiding waning products. Firstly, understanding local design preferences and cultural influences is essential for selecting furniture that resonates with Pakistani consumers. Quality remains paramount, with discerning buyers seeking durable materials and craftsmanship that <br>withstand the test of time. </p>
  </div>
</div>
</div>
<p class="learnbutton1">

<?php echo'<a href="user_productf.php?uno='.$user_id.'" style="text-decoration: none;color: white;">Shop Now</a>';?>
  </p>




   
<br><br><br>
<center>
        <img src="hand-love.png" alt="hand-love">
        
       <font size="+3px">
        <p style= "color: #007D69; ">
          Our Objective<br></p></font>
          <font size="+1px" >
     Welcome to GetRest, where customization meets comfort in the world of furniture. <br>
     At GetRest, we believe in empowering our customers to personalize their furniture to perfectly suit their unique tastes and preferences. From selecting the finest materials to choosing the perfect dimensions, our intuitive customization process puts you in control of creating furniture that reflects your individual style.<br>
     With GetRest, your imagination knows no bounds. Whether you're dreaming of a luxurious sofa in sumptuous velvet or a sleek dining table in rich wood finishes, our customizable options ensure that your vision becomes a reality.<br>
     Elevate your home with furniture that not only fits your space but also speaks to your personality and lifestyle.

<br>
Experience the ultimate in bespoke furniture design with GetRest. <br>
Let your creativity soar as you craft pieces that are as functional as they are beautiful. <br>
Discover the joy of furniture customization and transform your living spaces into expressions of your unique identity with GetRest.</font>
        </p>
    
       </font> 
      </center>
    


      <br>
      <center>
      <h1 style="font-size: +25px; color: #000000;" >

        Media & Press Coverage Of GetRest
      </h1>
      <p style="font-size: 50px; color: #007D69;">
        Media Center
      </p>
    </center>
      
      
      
      <br>


      <div class="container12">
        <div class="video" >
          <video width="600" poster="thumnail.jpg" controls>
            <source src="Cousins Furniture Promotional Video.mp4" type="video/mp4">
            <source src="mov_bbb.ogg" type="video/ogg">
           
          
        </div>
        <div class="text5">
          <h1 style="font-size: +30; color: #000000;"><br>JOIN US IN MAKING A DIFFERENCE</b></h1><br>
           <h3 style="font-size: +20; color: #000000; margin-left: -1.001%;">ENHANCE COMFORT AND TRANSFORM LIVES</h3><br>
           <p style="font-size: +17;"> Visit our Website to enhance comfort <br><br> More,Quality is our top priority.</p>
        </div>
      </div>
    
    
    <br>





    <div class="hero-image">
      <div class="hero-text">
        <h1 style="font-size:25px" ></h1><br>
       
      </div>
    </div>


    <div class="full">
      <div class="id">
    
        <div class="card1">
          <img src="team_9.jpg" alt="team_9" style="width:100%">
          <br><br>
          <h1 class="title">ALEXANDER GARY</h1>
          <p style="color: #000000; font-size: 48%;">CO-FOUNDER</p>
         
          <?php echo'<a href="user_contactf.php?uno='.$user_id.'"><button >Contact</button></a>';?>
        </div>
        </div>
        
        
        
        
        
        <div class="full">  
        <div class="id2">
        
          <div class="card2">
            <img src="99.jpg" alt="99" style="width:100%">
            <br><br>
            <h1 class="title">MELISSA MUNOZ</h1>
            <p style="color: #000000;font-size: 48%;">FOUNDER</p>

            <?php echo'<a href="user_contactf.php?uno='.$user_id.'"><button >Contact</button></a>';?>
          </div>
          </div>
        
        
        
        
          <div class="id3">
        
            <div class="card3">
              <img src="98.jpg" alt="98" style="width:100%">
              <br><br>
              <h1 class="title">JOHN ABRAHAM
              </h1>
              <p style="color: #000000;font-size: 48%;">MANAGER</p>
              
              <?php echo'<a href="user_contactf.php?uno='.$user_id.'"><button >Contact</button></a>';?>
            </div>
            </div>
            
          </div>



<br><br><br><br>


<style>
.float{
	position:fixed;
	width:60px;
	height:60px;
	bottom:20px;
	right:15px;
	background-color:#25d366;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}

.my-float{
	margin-top:16px;
} 
</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<a href="https://api.whatsapp.com/send?phone=+923310155706&text=GetRest How Can i Help You" class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>
<!-- footer -->
<footer>
  <div class="row">
    <div class="col">
      <h2 style="color: #007D69;">GetRest</h2>
      <p>
        Ferozpur Road Lahore
        <br><br>
        haiderb811@gmail.com
        <br><br>
        03310155706
      </p>
    </div>
    <div style="margin-left: %;">
  <div class="col"> 
   <h2>Office</h2>
   <p>Ferozpur Road</p>
   <p>Kalma Chowk, Lahore</p>
   <p>54600, Pakistan</p>
   <p class="email-id">haiderb811@gmail.com</p>
   <h4>+92 - 03310155706</h4>

  </div>
</div>

  <div class="col">
    <h2>Links</h2>
    
    <ul>
    
    <?php echo'<li><a href="user_homef.php?uno='.$user_id.'" target="_self">Home</a></li>';?>
    <?php echo'<li><a href="user_Aboutf.php?uno='.$user_id.'" target="_self">About</a></li>';?>
    <?php echo'<li><a href="user_productf.php?uno='.$user_id.'" target="_self">Product</a></li>';?>
    <?php echo'<li><a href="user_cartf.php?uno='.$user_id.'">Cart </a></li>';?>
    
    <?php echo'<li><a href="user_contactf.php?uno='.$user_id.'">Contact us</a></li>';?>
    
  </ul>
  </div>

  <div class="col">
<h2>NewsLette</h2>
<form>
  <div class="footer-section">
  <form action="#" method="post">
    <input type="email" name="email" placeholder="Your Email" style="color: black;">
    <button type="submit">Subscribe</button>
</form>

  </div>
  
  </div>
  </div>
</footer>
</div>
</div>

</body>