<?php
include 'dbconnect.php';
include 'user_check_login.php';
?>

<html>
<head>
    <title>Cart</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .container1 {
            width: 1100px;
            margin: auto;
            margin-bottom: 20px;
            height: 111px;
            border-radius: 10px;
            background: rgba(0, 125, 105, 0.7);
            backdrop-filter: blur(1px);
        }
        .container1:hover {
            background: rgba(0, 125, 105, 0.6);
        }
        .container1 .pic {
            height: 110px;
            width: 130px;
            float: left;
        }
        .pic img {
            width: 100px;
            height: 100px;
            position: relative;
            top: 5px;
            margin-left: 15px;
            border-radius: 10px;
            float: left;
        }
        .container1 .name1 {
            height: 110px;
            width: 400px;
            float: left;
        }
        .container1 .name {
            font-size: 22px;
            font-weight: 700;
            position: relative;
            left: 30px;
            top: 42px;
            letter-spacing: 1px;
            word-spacing: 5px;
            color: white;
        }
        .container1 .price1 {
            height: 110px;
            width: 150px;
            float: left;
        }
        .container1 .price {
            font-size: 15px;
            position: relative;
            left: 40px;
            top: 46px;
            color: white;
        }
        .price span {
            color: rgb(217, 255, 0);
            font-size: 17px;
            font-weight: 700;
        }
        .container1 .buttons {
            height: 110px;
            width: 420px;
            float: left;
        }
        .container1 .btn1 {
            width: 25%;
            height: 60px;
            position: relative;
            top: -10px;
            left: 12px;
            border-radius: 5px;
            background-color: #007D69;
        }
        .btn1:hover {
            background-color: rgb(0, 88, 74);
            color: white;
        }
        .container1 label {
            color: white;
            position: relative;
            margin-left: 180px;
            left: -130px;
            top: 15px;
            font-size: 16px;
        }
        .container1 select {
            width: 25%;
            position: relative;
            left: -195px;
            height: 35px;
            top: 50px;
            border-radius: 5px;
            outline: none;
            background-color: #007D69;
            color: white;
        }
        .checkout-details {
            margin-top: 20px;
            padding: 20px;
            background-color: #f0f0f0;
            border-radius: 10px;
        }
        .checkout-details h2 {
            color: #007D69;
        }
        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .invoice-table th,
        .invoice-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .invoice-table th {
            background-color: #f2f2f2;
        }
        .address-field {
            margin-top: 20px;
        }
        .address-field label {
            display: block;
            margin-bottom: 5px;
        }
        .address-field input {
            width: 100%;
            height: 35px;
            border-radius: 5px;
            border: 1px solid #ccc;
            padding: 8px;
            font-size: 14px;
            margin-top: 5px;
            box-sizing: border-box;
        }
    </style>
</head>
<?php


$user_id = $_GET['uno'];  // Assuming the user_id is passed as a query parameter

// Sample function to generate a unique order number
function generateOrderNumber() {
    return 'ORD-' . strtoupper(uniqid());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    $_SESSION['order_number'] = generateOrderNumber();
    header("Location: invoice.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cart</title>
    <link rel="stylesheet" href="styles.css"> <!-- Assuming you have a styles.css file -->
    <script src="js.js"></script> <!-- Assuming you have a js.js file -->
</head>
<body>
<div class="background1">
    <header>
        <div class="logo1">
            <h2>GetRest</h2>
        </div>
        <p class="aboutheader">
        <table class="nav-table">
            <nav>
                <ul>
                    <li><?php echo '<a href="user_homef.php?uno=' . $user_id . '" target="_self" style="color: black;">Home</a>'; ?></li>
                    <li><?php echo '<a href="user_Aboutf.php?uno=' . $user_id . '" target="_self" style="color: black;">About</a>'; ?></li>
                    <li><?php echo '<a href="user_productf.php?uno=' . $user_id . '" target="_self" style="color: black;">Product</a>'; ?></li>
                    <li><?php echo '<a href="user_cartf.php?uno=' . $user_id . '" target="_self" style="color: black;">Cart</a>'; ?></li>
                    <li>
                        <a href="#" target="_self" style="color: black;">Categories</a>
                        <div class="dropdown-content">
                            <?php
                            $sql = "SELECT * FROM `category`";
                            $result = mysqli_query($conn, $sql);
                            while ($data = mysqli_fetch_assoc($result)) {
                                $category_id = $data['category_id'];
                                $category_name = $data['category_name'];
                                echo '<a href="user_category.php?cid=' . $category_id . '&uno=' . $user_id . '" style="color: black;">' . $category_name . '</a>';
                            }
                            ?>
                        </div>
                    </li>
                    <li><?php echo '<a href="user_contactf.php?uno=' . $user_id . '" target="_self" style="color: black;">Contact us</a>'; ?></li>
                    <li><?php echo '<a href="user_logout.php?uno=' . $user_id . '" target="_self" style="color: black;">Logout</a>'; ?></li>
                </ul>
            </nav>
        </table>
        </p>
    </header>
    <center>
        <br><br><br><br><br><br>
        <p style="color: white; font-size: 40px;">CART</p>
    </center>
</div>

<br><br>
<?php
$sql = "SELECT * FROM `cart` WHERE `user_id` = $user_id";  // Filter by user_id
$result = mysqli_query($conn, $sql);
$row = ($result) ? mysqli_num_rows($result) : 0;
if ($row >= 1) {
    echo '<div id="cartItemsContainer">';
    while ($data = mysqli_fetch_assoc($result)) {
        $item_id = $data['item_id'];
        $category_id = $data['category_id'];
        $item_name = $data['item_name'];
        $item_price = $data['item_price'];
        $item_pic = $data['item_pic'];
        $item_desc = $data['item_desc'];
        $quantity = $data['quantity'];

        echo '<div class="container1">
            <div class="pic">
                <img src="' . $item_pic . '" alt="99">
            </div>
            <div class="name1">
                <p class="name">' . $item_name . '</p>
            </div>
            <div class="price1">
                <p class="price">RS : <span id="price-' . $item_id . '" data-price="' . $item_price . '">' . $item_price * $quantity . '</span>/-</p>
            </div>
            <div class="buttons">
                <label for="quantity">Quantity</label>
                <select class="form-select" aria-label="Default select example" name="quantity" onchange="updatePrice(' . $item_id . ', ' . $item_price . ', this.value)">
                    <option selected value="' . $quantity . '">' . $quantity . '</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </select>
                <form action="remove_cart_item.php?cid=' . $category_id . '&iid=' . $item_id . '&uno=' . $user_id . '" method="post">
                    <button type="submit" class="btn1" name="remove">Remove</button>
                </form>
            </div>
        </div>';
    }
    echo '</div>';
} else {
    echo '<p style="text-align: center;">Your cart is empty.</p>';
}
?>

<!-- Add "Buy and Proceed to Checkout" button -->
<div style="text-align: center; margin: 20px;">
    <button type="button" class="btn1" id="checkoutButton">Buy and Proceed to Checkout</button>
</div>

<!-- Checkout Details Container (hidden by default) -->
<div id="checkoutDetails" class="checkout-details" style="display: none;">
    <h2>Checkout Details</h2>
    <!-- Address Input Field -->
    <?php echo'<form action="check.php?uno='.$user_id.'" method="post">';?>
    <div class="address-field">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        
        <label for="cell">Cell No:</label>
        <input type="text" id="cell" name="cell" required>
        
        <label for="address">Address:</label>
        <input type="text" id="address" name="address" required>
    </div>
    
    <table class="invoice-table">
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Price per Item</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody id="checkoutItemsList">
            <!-- This will be dynamically populated with selected items -->
        </tbody>
        <tfoot>
        <tr>
            <td colspan="3" style="text-align: right;"><strong>Total Amount:</strong></td>
            <td id="totalAmount" style="font-weight: bold;"></td>
        </tr>
    </tfoot>
    </table>
    <input type="hidden" name="items" id="itemsInput">
    <div style="text-align: center; margin-top: 20px;">
        <button type="submit" name="checkout" class="btn1">Submit Order</button>
    </div>
</form>

<script>
document.getElementById('checkoutButton').addEventListener('click', function() {
    document.getElementById('checkoutDetails').style.display = 'block';

    var cartItems = document.getElementById('cartItemsContainer').getElementsByClassName('container1');
    var checkoutItemsList = document.getElementById('checkoutItemsList');
    checkoutItemsList.innerHTML = '';

    var itemsArray = [];
    var totalAmount = 0; // Initialize total amount

    for (var i = 0; i < cartItems.length; i++) {
        var itemContainer = cartItems[i];
        var itemName = itemContainer.querySelector('.name').textContent;
        var itemPrice = parseFloat(itemContainer.querySelector('.price span').getAttribute('data-price'));
        var itemQuantity = parseInt(itemContainer.querySelector('select[name="quantity"]').value);
        var itemSubtotal = itemPrice * itemQuantity;

        itemsArray.push({
            name: itemName,
            quantity: itemQuantity,
            price: itemPrice,
            subtotal: itemSubtotal
        });

        var row = checkoutItemsList.insertRow();
        row.insertCell(0).textContent = itemName;
        row.insertCell(1).textContent = itemQuantity;
        row.insertCell(2).textContent = 'RS ' + itemPrice.toFixed(2);
        row.insertCell(3).textContent = 'RS ' + itemSubtotal.toFixed(2);

        totalAmount += itemSubtotal; // Accumulate subtotal to total amount
    }

    document.getElementById('itemsInput').value = JSON.stringify(itemsArray);
    document.getElementById('totalAmount').textContent = 'RS ' + totalAmount.toFixed(2); // Display total amount
});

function updatePrice(itemId, itemPrice, quantity) {
    var priceElement = document.getElementById('price-' + itemId);
    var newPrice = itemPrice * quantity;
    priceElement.textContent = newPrice.toFixed(2);

    // Recalculate total amount when quantity changes
    var totalAmount = 0;
    var cartItems = document.getElementById('cartItemsContainer').getElementsByClassName('container1');
    for (var i = 0; i < cartItems.length; i++) {
        var itemContainer = cartItems[i];
        var itemPrice = parseFloat(itemContainer.querySelector('.price span').getAttribute('data-price'));
        var itemQuantity = parseInt(itemContainer.querySelector('select[name="quantity"]').value);
        totalAmount += itemPrice * itemQuantity;
    }

    document.getElementById('totalAmount').textContent = 'RS ' + totalAmount.toFixed(2); // Update total amount display
}
</script>
 
</body>
</html>



</body>
</html>
