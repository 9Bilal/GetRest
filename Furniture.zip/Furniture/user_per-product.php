<?php
  include 'user_check_login.php';
  require ('config.php');
  $cat_id  = $_GET['cid'];
  $item_id = $_GET['iid'];

  if(isset($_POST['add']))
  {
    $comment=$_POST['message'];
    header("location:/furniture/user_address.php?uno=".$user_id."&cid=".$cat_id."&iid=".$item_id."&q=1&comment=".$comment."");
  }
  $sql = "SELECT * FROM `users` WHERE `user_id` = '$user_id'";
  $result = mysqli_query($conn , $sql);
  $data = mysqli_fetch_assoc($result);
  $user_email = $data['user_email'];

  $sql = "SELECT * FROM `category_items` WHERE `category_id` = '$cat_id' AND `item_id` = '$item_id'";
  $result = mysqli_query($conn , $sql);
  $data = mysqli_fetch_assoc($result);
  $item_name  = $data['item_name'];
  $item_price = $data['item_price'];
  $item_image = $data['item_pic'];
  $item_desc  = $data['item_desc'];
  $desc = substr($item_desc , 0 , 50);

?>

<html>
  <head>
    <title>Per-Product</title>
  
   
  
    <link rel="stylesheet" href="css.css">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <style>
           .background100 {
            background-color: #007D69;
            height: 30%;
            margin-top: 7%;
         }
          

         * {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 500px;
  position: relative;
  margin: auto;
  left: -310px;
  border: 1px solid;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
  
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}



.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
  width: 100%;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
  width: 20%;
  color: #000;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
  width:100%;
  overflow:auto;
}
pre{
  white-space:pre-wrap;
  word-wrap:break-word;
}

.color1, .color2, .color3, .color4, .color5,
        .color6, .color7, .color8, .color9, .color10 {
            
            width: 40px;
            height: 36px;
            border-radius: 7px;
            display: inline-block;
            margin-top: 1%;
            cursor: pointer;
            box-sizing: border-box;
            margin-left: 1%;
        }

        .color1 { background-color: black; }
        .color2 { background-color: rgb(218, 170, 12); }
        .color3 { background-color: rgb(255, 0, 0); }
        .color4 { background-color: rgb(0, 158, 201); }
        .color5 { background-color: rgb(38, 209, 0); }
        
        .color6 { background-image: url('polish1.jpg'); background-size: cover; }
        .color7 { background-image: url('polish2.jpg'); background-size: cover; }
        .color8 { background-image: url('polish3.jpg'); background-size: cover; }
        .color9 { background-image: url('polish4.jpg'); background-size: cover; }
        .color10 { background-image: url('polish5.AVIF'); background-size: cover; }

        .fabric-title, .polish-title {
            margin-left: 52%;
            margin-top: 2%;
            color: #3c3c3c;
        }

        .fabric-colors, .polish-colors {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-left: 50%;
            transform: translateX(-28%);
        }

        .selected {
            border: 2px solid;
        }

.message1 {
  margin-left: 52%;
  margin-top: 2%;
  
}

     </style>
  

  </head>
  <body>
  <script src="js.js"></script>
      
  
  
  <div class="background100">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
          <?php echo'<li><a href="user_homef.php?uno='.$user_id.'" target="_self" style="color: black;">Home</a></li>
            <li><a href="user_Aboutf.php?uno='.$user_id.'" target="_self"style="color: black;">About</a></li>
            <li><a href="user_productf.php?uno='.$user_id.'" target="_self"style="color: black;">Product</a></li>
            <li><a href="user_cartf.php?uno='.$user_id.'" target="_self"style="color: black;">Cart</a></li>
            <li> <a href="#" target="_self"style="color: black;">Categories</a>
              <!-- Dropdown content -->
              <div class="dropdown-content">';?>
                  <?php
                    $sql = "SELECT * FROM `category`";
                    $result = mysqli_query($conn , $sql);
                    while($data = mysqli_fetch_assoc($result))
                    {
                      $category_id = $data['category_id'];
                      $category_name = $data['category_name'];
                      echo '<a href="user_category.php?cid='.$category_id.'&uno='.$user_id.'" style="color: black;">'.$category_name.'</a>';
                    }
                  ?>
              </div>
            </li>
            <?php echo'<li><a href="user_contactf.php?uno='.$user_id.'" target="_self"style="color: black;">Contact us</a></li>';?>
            
          </ul>
        </nav>
      </table>
    </p>
    </header>
    
        <center><p style="color: white;font-size: 40px; margin-top:3.2%; ">Per-Product</p></center>
    
  </div>


  <br><br><br>
  <div class="slideshow-container">
    <div class="mySlides fade">
      <?php echo'<img src="'.$item_image.'" style="width:100%;height:80%;">';?>
    </div>
  <?php
    $sql = "SELECT * FROM `item_images` WHERE `item_id` = '$item_id'";
    $result = mysqli_query($conn , $sql);
    while($data = mysqli_fetch_assoc($result))
    {
      $item_pic = $data['item_pic'];
      echo'<div class="mySlides fade">
        <img src="'.$item_pic.'" style="width:100%;height:80%;">
      </div>';
    }
  ?>
    
    
    </div>
    <br>
    
     <div class="margin-left" style="margin-left: 23%;">
      <span class="dot"></span> 
      <span class="dot"></span> 
      <span class="dot"></span> 
    </div>

    <script>
      let slideIndex = 0;
      showSlides();
      
      function showSlides() {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        let dots = document.getElementsByClassName("dot");
        for (i = 0; i < slides.length; i++) {
          slides[i].style.display = "none";  
        }
        slideIndex++;
        if (slideIndex > slides.length) {slideIndex = 1}    
        for (i = 0; i < dots.length; i++) {
          dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex-1].style.display = "block";  
        dots[slideIndex-1].className += " active";
        setTimeout(showSlides, 2000); // Change image every 2 seconds
      }
      </script>
      

    
      <h2 style="margin-left: 28%; margin-top: -41%; color: #232323;">
        <?php echo $item_name; ?>
      </h2>
  
    <p style="margin-left: 52%; margin-top: 2%; color: #3c3c3c;">
      Make By: GetRest
    </p>

  <p style="margin-left: 52%; margin-top: 1%; color: #3c3c3c;">
    Availability: In Stock
  </p>

  <p style="margin-left: 52%; margin-top: 1%; color: #3c3c3c;">
    Product Type: Furniture
  </p>

  <p style="margin-left: 52%; margin-top: 3%; color: #3c3c3c; font-size: 20px;">
    <strong>Rs.<em><?php echo $item_price; ?></em></strong>
  </p>
  
  <p style="margin-left: 52%; margin-top: 2%; color: #3c3c3c;">
    <strong>Description : </strong><?php echo $desc; ?>...
  </p>


<!-- 
<p class="fabric-title"><strong>Fabric Color :</strong></p>
    <div class="fabric-colors">
        <div class="color1"></div>
        <div class="color2"></div>
        <div class="color3"></div>
        <div class="color4"></div>
        <div class="color5"></div>
    </div>

    <p class="polish-title"><strong>Polish Colors :</strong></p>
    <div class="polish-colors">
        <div class="color6"></div>
        <div class="color7"></div>
        <div class="color8"></div>
        <div class="color9"></div>
        <div class="color10"></div>
    </div> -->

    <script>
        // Function to handle selection
        function handleSelection(containerSelector) {
            document.querySelectorAll(containerSelector + ' div').forEach(function(element) {
                element.addEventListener('click', function() {
                    // Remove 'selected' class from all elements within the container
                    document.querySelectorAll(containerSelector + ' div').forEach(function(el) {
                        el.classList.remove('selected');
                    });
                    // Add 'selected' class to the clicked element
                    element.classList.add('selected');
                });
            });
        }

        // Apply selection handler to fabric and polish colors separately
        handleSelection('.fabric-colors');
        handleSelection('.polish-colors');
    </script>





      <?php echo'<form action="/furniture/user_per-product.php?cid='.$cat_id.'&iid='.$item_id.'&uno='.$user_id.'" method="post">';?>
      <div class="message1" style="position:relative;right:225px;">
          <p style= "color: #3c3c3c;">
          <strong>Details:</strong>
          </p><br>
          <textarea id="message" name="message" rows="7" style="width: 250%;"></textarea>
      </div>
      <button type="submit" name="add" class="button" style="width:150px;margin-left: 16%; margin-top: 2%;"> Buy</button>
    </form>


      <?php echo'<form action="/furniture/add_to_cart.php?cid='.$cat_id.'&iid='.$item_id.'&uno='.$user_id.'" method="post">';?>

      <button type="submit" name="add" class="button" style="width:150px;margin-left: 43%; margin-top: -8.3%;"> Add to Cart</button>
    </form>

    
  
     
</form>


<br>


  <div class="tab">
    <button class="tablinks" onclick="openCity(event, 'Description')">Description</button>
    <button class="tablinks" onclick="openCity(event, 'Delivery Time')">Delivery Time</button>
    <button class="tablinks" onclick="openCity(event, 'Shipping & Returns')">Shipping & Returns</button>
  </div>
  
  <div id="Description" class="tabcontent">
    <h3>Description:</h3><br>
    <pre><?php echo $item_desc; ?></pre>
    <br><br>
      <br>
      

  </div>
  
  <div id="Delivery Time" class="tabcontent">
    <h3>Delivery Time:</h3><br>
   <p> <li> Please allow a delivery timeline of 15 to 25 working days for all furnitureproducts and 5 to 7 working days for home accessories. For promotional products, please refer to <br>the product description for the specific delivery time mentioned.<br><br></li>
     <li> If your order includes both furniture and home items, our system will calculate the delivery charges based on the applicable charges for furniture items.<br></li><br>
     <li> Delivery to other cities is subject to additional charges depending on your destination, and our sales representative will communicate these charges to you.<br></li><br>
      <li><b>Note: </b>Our delivery team will call you to provide exact delivery timelines for urgent deliveries.</p> </li>
  </div>
  
  <div id="Shipping & Returns" class="tabcontent">
    <h3>TERMS & CONDITION</h3><br>
    <p>
     <li> We have done our best to display as accurately as possible the colors of the products shown on this Website. However, because the colors you see will depend on your monitor, we cannot guarantee that your monitor’s display of any color will be accurate.</li><br>
     <li>The photo may include additional props that are for display purpose only, and will not be included.</li> <br>
      <li>The actual measurement maybe a little bit different than described due to manual measurement.</li><br>
     <li> 100% advance payment is required at the time of booking for timely order processing of standard orders.</li><br>
      <li>Deliveries are made within 25 working days after receiving full payment at the concerned store. In case payment is made by cheque, the delivery will be made 25 working days after the amount is transferred.</li><br>
      <li>We will not cater cancelation of any order after payment received.</li><br>
      <li>Gift Card is not applicable on the category of Bazaar products.</li><br>  
     <li> No return / refund will be applicable, if you receive the same product as seen on website in perfect condition, (change of mind is not applicable).</li><br>
      <li>In case customer delays order delivery beyond 30 days after the original delivery date, the order will be considered canceled and cancellation charges of 20% of order amount will be deducted.</li><br>
      <li>Any order can be changed or modified 10 days before delivery based on following conditions:</li><br><br>
     <ol type="1"...><li> New order amount is greater or equal to original order.</li> 
      <li>New delivery date will be communicated according to products availability.</li>
      <li>Order cannot be changed or modified after delivery.</li></ol>
     
      </p>
  </div>

  <script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>

<style>
.float{
	position:fixed;
	width:60px;
	height:60px;
	bottom:20px;
	right:15px;
	background-color:#25d366;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}

.my-float{
	margin-top:16px;
} 
</style>

<br>

<!-- footer -->
<footer>
    <div class="row">
      <div class="col">
        <h2 style="color: #007D69;">GetRest</h2>
        <p>
          Ferozpur Road Lahore
          <br><br>
          haiderb811@gmail.com
          <br><br>
          03310155706
        </p>
      </div>
      <div style="margin-left: 0;">
    <div class="col"> 
     <h2>Office</h2>
     <p>Ferozpur Road</p>
     <p>Kalma Chowk, Lahore</p>
     <p>54600, Pakistan</p>
     <p class="email-id">haiderb811@gmail.com</p>
     <h4>+92 - 03310155706</h4>
  
    </div>
  </div>
  
    <div class="col">
      <h2>Links</h2>
      
      <ul>
       <li><a href="homef.php">Home</a></li>
       <li><a href="Aboutf.php">About</a></li>
        <li><a href="productf.php">Product </a></li>
        <li><a href="cardf.php">Cart </a></li>
        <li><a href="contactf.php">Contact </a></li>
      </ul>
    </div>
  
    <div class="col">
  <h2>NewsLette</h2>
  <form>
    <div class="footer-section">
    <form action="#" method="post">
      <input type="email" name="email" placeholder="Your Email" style="color: black;">
      <button type="submit">Subscribe</button>
  </form>
  
    </div>
    
    </div>


<!--    Introduction:

Welcome to our online store, where we believe that your bedroom should be a reflection of your individuality and a space where you can relax and recharge. Introducing the Mack Bed, a perfect blend of modern minimalism and innovative design. With its laminated construction, stylish light brown and white shades, and unique features, the Mack Bed offers a contemporary look that will instantly enhance the aesthetics of your bedroom. Let's explore the remarkable design and functionality that make our Mack Bed a must-have for those seeking a modern and space-saving solution.

Material:  Metal Rod in Headboard and Lamination structure

Mack Bed Is a Floor Bed

Dimensions:

Total Length: 6.7 ft
Total width: 6.08 ft
Total Height: 2.83 ft 
Shelf: 6 Inches 
Planks: 4 Inches
Size: King Size Bed -->
 