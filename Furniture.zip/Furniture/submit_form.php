<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "Furniture";

    $conn = mysqli_connect($servername , $username , $password , $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO message (name, email, city, message) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $email, $city, $message);

// Set parameters and execute
$name = $_POST['name'];
$email = $_POST['email'];
$city = $_POST['city'];
$message = $_POST['message'];
$stmt->execute();
    
echo "Send Message Successfully";

$stmt->close();
$conn->close();
?>
