<?php
  include 'dbconnect.php';
?>


<html><head>
    <title>Cart</title>
  
    <meta charset="utf-8">
  
    <link rel="stylesheet" href="css.css">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
      .container1{
        width:1100px;
        margin:auto;
        margin-bottom:20px;
        height:111px;
        border-radius:10px;
        background: rgba(0, 125, 105, 0.7);
        backdrop-filter: blur(1px);
      }

      .container1:hover{
        background: rgba(0,125,105,0.6);
      }

      .container1 .pic{
        height:110px;
        width:130px;
        float:left;
      }

      .pic img{
        width:100px;
        height:100px;
        position:relative;
        top:5px;
        margin-left:15px;
        border-radius:10px;
        float:left;
      }

      .container1 .name1{
        height:110px;
        width:400px;
        float:left;
      }

      .container1 .name{
        font-size:22px;
        font-weight: 700;
        position:relative;
        left:30px;
        top:42px;
        letter-spacing: 1px;
        word-spacing: 5px;
        color:white;
      }

      .container1 .price1{
        height:110px;
        width:150px;
        float:left;
      }

      .container1 .price{
        font-size: 15px;
        position: relative;
        left:40px;
        top:46px;
        color:white;
      }

      .price span{
        color:rgb(217, 255, 0);
        font-size:17px;
        font-weight: 700;
      }

      .container1 .buttons{
        height:110px;
        width:420px;
        float:left;
      }

      .container1 .btn1{
        width:25%;
        height:60px;
        position:relative;
        top:-10px;
        left:12px;
        border-radius: 5px;
        background-color: #007D69;
      }

      .btn1:hover{
        background-color: rgb(0, 88, 74);
        color:white;
      }

      .container1 .btn2{
        width:25%;
        height:60px;
        position:relative;
        top:-136px;
        left:135px;
        border-radius: 5px;
        background-color: #007D69;
      }

      .btn2:hover{
        background-color: rgb(0, 88, 74);
        color:white;
      }
      
      .container1 label{
        color:white;
        position:relative;
        margin-left:180px;
        left:-130px;
        top:15px;
        font-size:16px;
      }

      .container1 select{
        width:25%;
        position:relative;
        left:-195px;
        height:35px;
        top:50px;
        border-radius: 5px;
        outline: none;
        background-color: #007D69;
        color:white;
      }


    </style>
  
  </head>
  <body>
  <script src="js.js"></script>
      
  
  
  <div class="background1">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
            <li><a href="homef.php" target="_self" style="color: black;">Home</a></li>
            <li><a href="Aboutf.php" target="_self"style="color: black;">About</a></li>
            <li><a href="productf.php" target="_self"style="color: black;">Product</a></li>
            <li><a href="cardf.php" target="_self"style="color: black;">Cart</a></li>
            <li>
              <a href="#" target="_self"style="color: black;">Categories</a>
              <!-- Dropdown content -->
              <div class="dropdown-content">
                  <?php
                    $sql = "SELECT * FROM `category`";
                    $result = mysqli_query($conn , $sql);
                    while($data = mysqli_fetch_assoc($result))
                    {
                      $category_id = $data['category_id'];
                      $category_name = $data['category_name'];
                      echo '<a href="category.php?cid='.$category_id.'" style="color: black;">'.$category_name.'</a>';
                    }
                  ?>
              </div>
            </li>
            <li><a href="contactf.php" target="_self"style="color: black;">Contact us</a></li>
            
          </ul>
        </nav>
      </table>
    </p>
    </header>
    <p class="headertext">
        <center><p style="color: white;font-size: 40px;">CART</p></center>
    </p>
  </div>

  <br><br>
  <?php
  $sql = "SELECT * FROM `cart`";
  $result = mysqli_query($conn , $sql);
  $row = mysqli_num_rows($result);
  if($row>=1)
  {
    while($data = mysqli_fetch_assoc($result))
    {
      $item_id = $data['item_id'];
      $category_id = $data['category_id'];
      $item_name = $data['item_name'];
      $item_price = $data['item_price'];
      $item_pic  = $data['item_pic'];
      $item_desc = $data['item_desc'];
      $quantity = $data['quantity'];

      echo'<a href="Per-Product.php?cid='.$category_id.'&iid='.$item_id.'">
      <div class="container1">
    <div class="pic">
    <img src="'.$item_pic.'" alt="99">
  </div>
  <div class="name1">
    <p class="name">'.$item_name.'</p>
  </div>
  <div class="price1">
    <p class="price">RS : <span>'.$item_price.'</span>/-</p> 
  </div>
  </a>

  <div class="buttons">
    <label for="quantity">Quantity</label>
      <select class="form-select" aria-label="Default select example" name="quantity">
        <option selected value="'.$quantity.'">'.$quantity.'</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="3">4</option>
        <option value="3">5</option>
      </select>
  <form action="/furniture/remove_cart_item.php?cid='.$category_id.'&iid='.$item_id.'" method="post">
    <button type="submit" class="btn1" name="remove">Remove</button>
  </form>
  <form action="" method="post">
    <button type="submit" class="btn2" name="buy">Buy</button>
  </form>
  </div>
    
  </div>';
    }
  }
  ?>
  
  <script src="https://static.elfsight.com/platform/platform.js" data-use-service-core defer></script>
<div class="elfsight-app-c2a9557d-67c0-4c40-81bf-3cec7a574b7c" data-elfsight-app-lazy></div>



<!-- footer -->
<footer>
    <div class="row">
      <div class="col">
        <h2 style="color: #007D69;">GetRest</h2>
        <p>
          Ferozpur Road Lahore
          <br><br>
          haiderb811@gmail.com
          <br><br>
          03310155706
        </p>
      </div>
      <div style="margin-left: 0;">
    <div class="col"> 
     <h2>Office</h2>
     <p>Ferozpur Road</p>
     <p>Kalma Chowk, Lahore</p>
     <p>54600, Pakistan</p>
     <p class="email-id">haiderb811@gmail.com</p>
     <h4>+92 - 03310155706</h4>
  
    </div>
  </div>
  
    <div class="col">
      <h2>Links</h2>
      
      <ul>
       <li><a href="homef.php">Home</a></li>
       <li><a href="Aboutf.php">About</a></li>
        <li><a href="productf.php">Product </a></li>
        <li><a href="cardf.php">Cart </a></li>
        <li><a href="contactf.php">Contact </a></li>
      </ul>
    </div>
  
    <div class="col">
  <h2>NewsLette</h2>
  <form>
    <div class="footer-section">
    <form action="#" method="post">
      <input type="email" name="email" placeholder="Your Email" style="color: black;">
      <button type="submit">Subscribe</button>
  </form>
  
    </div>
    
    </div>