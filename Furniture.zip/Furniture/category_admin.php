<?php
    include 'dbconnect.php';

    include 'admin_check_login.php';
    $cat_id = $_GET['cid'];

    $sql = "SELECT * FROM `category` WHERE `category_id` = '$cat_id'";
    $result = mysqli_query($conn , $sql);
    $data = mysqli_fetch_assoc($result);
    $cat_name = $data['category_name'];

?>

<html><head>
    <title>items</title>
  
  
  
    <link rel="stylesheet" href="css.css">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    .dropdown-content1 {
  display: none;
  position: absolute;
  background-color: #e2e1e1;
  box-shadow: 0 4px 1px rgba(173, 107, 107, 0.1);
  z-index: 1;
  margin-left: 16%;
}
.dropdown-content1 a {
  display: block;
  padding: 9px;
  color: #007D69;
}


/* Show dropdown on hover */
nav li:hover .dropdown-content1 {
  display: block;
}
</style>
  
  </head>
  <body>
  <script src="js.js"></script>
      
  
  
  <div class="background1">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
            <?php echo'<li><a href="admin_furniture.php?ano='.$admin_id.'" target="_self"style="color: black;">Add New Category</a></li>';?>
            <?php echo'<li> <a href="category_admin.php?cid=1&ano='.$admin_id.'" target="_self"style="color: black;">Categories</a>';?>
              <!-- Dropdown content -->
             
              <div class="dropdown-content1">
                  <?php
                    $sql = "SELECT * FROM `category`";
                    $result = mysqli_query($conn , $sql);
                    while($data = mysqli_fetch_assoc($result))
                    {
                      $category_id = $data['category_id'];
                      $category_name = $data['category_name'];
                      echo '<a href="category_admin.php?cid='.$category_id.'&ano='.$admin_id.'" style="color: black;">'.$category_name.'</a>';
                    }
                  
                  echo'<li><a href="order.php?ano='.$admin_id.'" target="_self"style="color: black;">Orders</a></li>';?>
              </div>

            </li>
            
            <?php echo'<li><a href="multiple.php?ano='.$admin_id.'" target="_self"style="color: black;">multiple item orders</a></li>';?>
            <?php echo'<li><a href="admin_logout.php?ano='.$admin_id.'" target="_self"style="color: black;">Logout</a></li>';?>

          </ul>
        </nav>
      </table>
    </p>
    </header>
    <p class="headertext">
        <center><p style="color: white;font-size: 40px;"><?php echo $cat_name; ?></p></center>
    </p>
  </div>







<br><br>

<h2 style="color: #007D69;">CUSTOMER FAVOURITES</h2>


<br><br><br><br>
<div class="row">
    <?php  
    $sql = "SELECT * FROM `category_items` WHERE `category_id` = '$cat_id'";
    $result = mysqli_query($conn , $sql);
    while($data = mysqli_fetch_assoc($result))
    {
        $item_id    = $data['item_id'];
        $item_name  = $data['item_name'];
        $item_price = $data['item_price'];
        $item_pic   = $data['item_pic'];

        $query = "SELECT * FROM `cart` WHERE `category_id` = '$cat_id' AND `item_id` = '$item_id'";
        $result2 = mysqli_query($conn , $query);
        $row  = mysqli_num_rows($result2);
        if($row <= 0)
        {
          echo '<div class="column" style="margin-bottom:40px;">
            <a href="/furniture/per-product.php?cid='.$cat_id.'&iid='.$item_id.'"><div class="card">
                <img src="'.$item_pic.'" alt="bed7" width="220px" height="213px">
                <p style="font-size:16px;margin-top: 5%;">'.$item_name.'</p>
                <h6 style="color: #007D69;">Rs '.$item_price.'</h6>
                <br>
                <form action="/furniture/delete_item.php?cid='.$cat_id.'&iid='.$item_id.'&ano='.$admin_id.'" method="post">
                  <button type="submit" name="del_item" class="button" style="width:160px;">Delete</submit>
                </form>
            </div></a>
            <form action="/furniture/edit_item.php?cid='.$cat_id.'&iid='.$item_id.'&ano='.$admin_id.'" method="post">
                  <button type="submit" name="edit_item" class="button" style="width:160px;">Edit</submit>
                </form>
          </div>';
        } 
    }
    ?>
</div>



<br><br><br><br>

<!-- footer -->
<footer>
  <div class="row">
    <div class="col">
      <h2 style="color: #007D69;">GetRest</h2>
      <p>
        Ferozpur Road Lahore
        <br><br>
        haiderb811@gmail.com
        <br><br>
        03310155706
      </p>
    </div>
    <div style="margin-left: %;">
  <div class="col"> 
   <h2>Office</h2>
   <p>Ferozpur Road</p>
   <p>Kalma Chowk, Lahore</p>
   <p>54600, Pakistan</p>
   <p class="email-id">haiderb811@gmail.com</p>
   <h4>+92 - 03310155706</h4>

  </div>
</div>

  <div class="col">
    <h2>Links</h2>
    
    <ul>
    <li><a href="homef.php">Home</a></li>
       <li><a href="Aboutf.php">About</a></li>
        <li><a href="productf.php">Product </a></li>
        <li><a href="cardf.php">Cart </a></li>
        <li><a href="contactf.php">Contact </a></li>
    </ul>
  </div>

  <div class="col">
<h2>NewsLette</h2>
<form>
  <div class="footer-section">
  <form action="#" method="post">
    <input type="email" name="email" placeholder="Your Email" style="color: black;">
    <button type="submit">Subscribe</button>
</form>

  </div>
  
  </div>