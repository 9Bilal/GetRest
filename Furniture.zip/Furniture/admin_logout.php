<?php
    session_start();
    include 'dbconnect.php';
    $admin_id = $_GET['ano'];
    $sql = "SELECT * FROM `admin` WHERE `admin_id` = '$admin_id'";
    $result = mysqli_query($conn , $sql);
    $row = mysqli_num_rows($result);
    if($row>=1)
    {
        unset($_SESSION['admin_id']);
        session_destroy();
        header("location:/furniture/homef.php");
        exit;
    }

?>