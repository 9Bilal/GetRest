<?php
    include 'admin_check_login.php';
    $cat_id = $_GET['cid'];

    $sql = "DELETE FROM `category_items` WHERE `category_id` = '$cat_id'";
    $result = mysqli_query($conn , $sql);
    $sql = "DELETE FROM `category` WHERE `category_id` = '$cat_id'";
    $result = mysqli_query($conn , $sql);

    header("location:/furniture/admin_furniture.php?ano=".$admin_id."");



?>