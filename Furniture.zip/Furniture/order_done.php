<?php
    include 'admin_check_login.php';
    $id = $_GET['oid'];
    if(isset($_POST['done']))
    {
        $sql = "DELETE FROM `orders` WHERE `id` = '$id'";
        $result = mysqli_query($conn , $sql);
        header("location:/furniture/order.php?ano=".$admin_id."");
    }

?>