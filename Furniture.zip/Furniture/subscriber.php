<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "Furniture";

    $conn = mysqli_connect($servername , $username , $password , $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO subscribe (email) VALUES (?)");
$stmt->bind_param("s", $email);

// Set parameters and execute
$email = $_POST['email'];
$stmt->execute();
    
echo "Successfully";

$stmt->close();
$conn->close();
?>



