<?php
  include 'dbconnect.php';
?>


<html><head>
    <title>Bed</title>
  
  
  
    <link rel="stylesheet" href="css.css">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  
  </head>
  <body>
  <script src="js.js"></script>
      
  
  
  <div class="background1">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
          <li><a href="homef.php" target="_self" style="color: black;">Home</a></li>
            <li><a href="Aboutf.php" target="_self"style="color: black;">About</a></li>
            <li><a href="productf.php" target="_self"style="color: black;">Product</a></li>
            <li><a href="loginf.php" target="_self"style="color: black;">Cart</a></li>
            <li> <a href="#" target="_self"style="color: black;">Categories</a>
              <!-- Dropdown content -->
              <div class="dropdown-content">
                <a href="bedf.php"style="color: black;">BED</a>
                <a href="sofaf.php"style="color: black;">SOFA</a>
                <a href="kidsf.php"style="color: black;">KIDS</a>
                <a href="chairf.php"style="color: black;">CHAIR</a>
              </div>
            </li>
            <li><a href="contactf.php" target="_self"style="color: black;">Contact us</a></li>
            
          </ul>
        </nav>
      </table>
    </p>
    </header>
    <p class="headertext">
        <center><p style="color: white;font-size: 40px;">BED</p></center>
    </p>
  </div>







<br><br>

<h2 style="color: #007D69;">CUSTOMER FAVOURITES</h2>

<br><br><br><br>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="bed.jpg" alt="bed" width="220px" height="213px">
      <p style="margin-top: 5%;">Gomze Double Bed</p>
      <h5 style="color: #007D69;">Rs 140,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="bed3.jpg" alt="bed3" width="220px" height="213px">
      <p style="margin-top: 5%;">long Headboard Bed</p>
      <h5 style="color: #007D69;">Rs 180,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="bed2.jpg" alt="bed2" width="220px" height="213px">
      <p style="margin-top: 5%;">Cresta Bed</p>
      <h5 style="color: #007D69;">Rs 120,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="bed4.jpg" alt="bed4" width="220px" height="213px">
      <p style="margin-top: 5%;">Mocca Double Bed</p>
      <h5 style="color: #007D69;">Rs 150,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>
</div>
<br><br><br><br>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="bed7.jpg" alt="bed7" width="220px" height="213px">
      <p style="margin-top: 5%;">Hauga Upholstered Bed</p>
      <h5 style="color: #007D69;">Rs 99,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="bed6.jpg" alt="bed6" width="220px" height="213px">
      <p style="margin-top: 5%;">Oyster Upholstered Bed</p>
      <h5 style="color: #007D69;">Rs 199,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="bed9.jpg" alt="bed9" width="220px" height="213px">
      <p style="margin-top: 5%;">Zimer Bed</p>
      <h5 style="color: #007D69;">Rs 170,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="bed8.jpg" alt="bed8" width="220px" height="213px">
      <p style="margin-top: 5%;">Lily Bed</p>
      <h5 style="color: #007D69;">Rs 144,000</h5>
    <br>
      <a href="cardf.php" class="button"> Add to Cart</a>
    </div>
  </div>
</div>



<br><br><br><br>
<script src="https://static.elfsight.com/platform/platform.js" data-use-service-core defer></script>
<div class="elfsight-app-c2a9557d-67c0-4c40-81bf-3cec7a574b7c" data-elfsight-app-lazy></div>


<!-- footer -->
<footer>
  <div class="row">
    <div class="col">
      <h2 style="color: #007D69;">GetRest</h2>
      <p>
        Ferozpur Road Lahore
        <br><br>
        haiderb811@gmail.com
        <br><br>
        03310155706
      </p>
    </div>
    <div style="margin-left: %;">
  <div class="col"> 
   <h2>Office</h2>
   <p>Ferozpur Road</p>
   <p>Kalma Chowk, Lahore</p>
   <p>54600, Pakistan</p>
   <p class="email-id">haiderb811@gmail.com</p>
   <h4>+92 - 03310155706</h4>

  </div>
</div>

  <div class="col">
    <h2>Links</h2>
    
    <ul>
    <li><a href="homef.php">Home</a></li>
       <li><a href="Aboutf.php">About</a></li>
        <li><a href="productf.php">Product </a></li>
        <li><a href="cardf.php">Cart </a></li>
        <li><a href="contactf.php">Contact </a></li>
    </ul>
  </div>

  <div class="col">
<h2>NewsLette</h2>
<form>
  <div class="footer-section">
  <form action="#" method="post">
    <input type="email" name="email" placeholder="Your Email" style="color: black;">
    <button type="submit">Subscribe</button>
</form>

  </div>
  
  </div>