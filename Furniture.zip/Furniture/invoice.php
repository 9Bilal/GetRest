<?php
session_start();

if (!isset($_SESSION['order_number'])) {
    header("Location: cart.php");
    exit;
}

$order_number = $_SESSION['order_number'];
$items = json_decode($_POST['items'], true);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Invoice</title>
    <link rel="stylesheet" href="styles.css"> <!-- Assuming you have a styles.css file -->
</head>
<body>
    <h1>Invoice</h1>
    <p>Order Number: <?php echo $order_number; ?></p>
    <table border="1">
        <tr>
            <th>Item Name</th>
            <th>Quantity</th>
            <th>Price per Item</th>
            <th>Subtotal</th>
        </tr>
        <?php foreach ($items as $item): ?>
        <tr>
            <td><?php echo htmlspecialchars($item['name']); ?></td>
            <td><?php echo htmlspecialchars($item['quantity']); ?></td>
            <td><?php echo 'RS ' . number_format($item['price'], 2); ?></td>
            <td><?php echo 'RS ' . number_format($item['subtotal'], 2); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
