<?php
    include 'dbconnect.php';
    $user_id = $_GET['uno'];
    $type= $_GET['type'];

    if(isset($_POST['submit_pass']))
    {
        $pass = $_POST['pass'];
        $c_pass = $_POST['c_pass'];

        if($type == "admin")
        {
            if($pass == $c_pass)
            {
                $sql = "UPDATE `admin` SET `admin_pass` = '$pass'";
                $result = mysqli_query($conn , $sql);
                header("location:/furniture/loginf.php");
            }
        }
        else
        if($type == "users")
        {
            if($pass == $c_pass)
            {
                $sql = "UPDATE `users` SET `user_pass` = '$pass'";
                $result = mysqli_query($conn , $sql);
                header("location:/furniture/loginf.php");
            }
        }
    }


?>

<html>
    <head>
       
</head>
<body>



<style>

.code22 {
margin-left: 43%;
margin-top: -3%;

}
.code221 {
margin-left: 43%;
margin-top: -3%;

}

.forgotsubmitbtn {
  margin-left: 44%;
  margin-top: 2%;
  
}
 



</style>
</head>

<body>

<h1 style="margin-left: 39%; margin-top: 0%; color: #007D69;">New Password</h1>
<h3 style="margin-left: 30%; margin-top: 7%; color: #007D69;">Change Password:</h3>
<?php echo'<form action="/furniture/change_password.php?uno='.$user_id.'&type='.$type.'" method="post">';?>
<div class="code22">
<input type="text" name="pass" style="width: 27%;" required>
</div>
<h3 style="margin-left: 30%; margin-top: 3%; color: #007D69;">Confirm Password:</h3>
<div class="code221">
<input type="text" name="c_pass" style="width: 27%;" required>
</div>

<div class="forgotsubmitbtn">
    <input type="submit" name="submit_pass" value="submit" style="width: 10%;">
</form>
</div>

</body>
</html>