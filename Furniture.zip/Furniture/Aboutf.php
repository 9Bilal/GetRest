<?php
  include 'dbconnect.php';
?>


<html><head>
    <title>About</title>
  
  
  
    <link rel="stylesheet" href="css.css">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  
  </head>
  <body>
  <script src="js.js"></script>
      
  
  
  <div class="background1">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
          <li><a href="homef.php" target="_self" style="color: black;">Home</a></li>
            <li><a href="Aboutf.php" target="_self"style="color: black;">About</a></li>
            <li><a href="productf.php" target="_self"style="color: black;">Product</a></li>
            <li><a href="loginf.php" target="_self"style="color: black;">Cart</a></li>
            <li> <a href="#" target="_self"style="color: black;">Categories</a>
              <!-- Dropdown content -->
              <div class="dropdown-content">
                  <?php
                    $sql = "SELECT * FROM `category`";
                    $result = mysqli_query($conn , $sql);
                    while($data = mysqli_fetch_assoc($result))
                    {
                      $category_id = $data['category_id'];
                      $category_name = $data['category_name'];
                      echo '<a href="category.php?cid='.$category_id.'" style="color: black;">'.$category_name.'</a>';
                    }
                  ?>
              </div>
            </li>
            
            <li><a href="contactf.php" target="_self"style="color: black;">Contact us</a></li>
            
          </ul>
        </nav>
      </table>
    </p>
    </header>
    <p class="headertext">
        <center><p style="color: white;font-size: 40px;">ABOUT US</p></center>
    </p>
  </div>

  <br><br><br><br><br><br>
  <p class="chairabout">
  <img src="yellowchair.png" alt="yellowchair" width="500px" height="300px">
</p>



<h1 class="text7">
    Best Furniture
  </h1>
  <div class="center-align">
    

  <p class="text8">
    In navigating the furniture market in Pakistan, several considerations <br>can  help in avoiding waning products. Firstly, understanding local design preferences and cultural influences is essential for selecting furniture that <br>resonates with Pakistani consumers.<br> Quality remains paramount, with discerning buyersseeking durable <br> materials and craftsmanship that
    withstand the test of time<br> GetRest.
  </p>
</div>
  <br>
  <p class="learnbutton3">
  <a href="productf.php" style="text-decoration: none;color: white;">Shop Now</a>
  </p>

<br><br><br>
  <div class="background-image-div">
    
  <center> 
    
    <h1 style="color: rgb(255, 255, 255); margin-top: -3%;">
    New Furniture
   </h1>
   <h2 style="color: #ffffff;margin-top: -4px;">
    Sofa Set
   </h2>
   <p class="learnbutton4">
    <a href="productf.php" style="text-decoration: none;color: rgb(255, 255, 255);">Shop Now</a>
    </p>
</center>
  </div>
<br><br>


<center>
  <h1 style="color: #007D69;"> GetRest Owners</h1>
  
</center>
<br>
  <div class="container">
    <img src="team_9.jpg" alt="team_9" style="width:90px">
    <p style="margin-top: 3%;"><span>John Abraham</span> CO-FOUNDER</p>
    <p>No one is better than John Abraham.</p>
  </div>
  
  <div class="container">
    <img src="99.jpg" alt="99" style="width:90px">
    <p style="margin-top: 8%;"><span>Melissa Munoz.</span> FOUNDER.</p>
    <p>No one is better than Melissa Munoz.</p>
  </div>
  
  <div class="container">
    <img src="98.jpg" alt="98" style="width:90px">
    <p style="margin-top: 8%;"><span>Alexander Gary.</span> MANAGER.</p>
    <p>No one is better than Alexander Gary.</p>
  </div>


<br><br>
<hr>
<br><br>



<style>
.float{
	position:fixed;
	width:60px;
	height:60px;
	bottom:20px;
	right:15px;
	background-color:#25d366;
	color:#FFF;
	border-radius:50px;
	text-align:center;
  font-size:30px;
	box-shadow: 2px 2px 3px #999;
  z-index:100;
}

.my-float{
	margin-top:16px;
} 
</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<a href="https://api.whatsapp.com/send?phone=+923310155706&text=GetRest How Can i Help You" class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>
<!-- footer -->
<footer>
  <div class="row">
    <div class="col">
      <h2 style="color: #007D69;">GetRest</h2>
      <p>
        Ferozpur Road Lahore
        <br><br>
        haiderb811@gmail.com
        <br><br>
        03310155706
      </p>
    </div>
    <div style="margin-left: %;">
  <div class="col"> 
   <h2>Office</h2>
   <p>Ferozpur Road</p>
   <p>Kalma Chowk, Lahore</p>
   <p>54600, Pakistan</p>
   <p class="email-id">haiderb811@gmail.com</p>
   <h4>+92 - 03310155706</h4>

  </div>
</div>

  <div class="col">
    <h2>Links</h2>
    
    <ul>
    <li><a href="homef.php">Home</a></li>
       <li><a href="Aboutf.php">About</a></li>
        <li><a href="productf.php">Product </a></li>
        <li><a href="cardf.php">Cart   </a></li>
        <li><a href="contactf.php">Contact </a></li>
    </ul>
  </div>

  <div class="col">
<h2>NewsLette</h2>
<form>
  <div class="footer-section">
  <form action="subscribe.php" method="post">
    <input type="email" name="email" placeholder="Your Email" style="color: black;">
    <button type="submit">Subscribe</button>
</form>

  </div>
  
  </div>