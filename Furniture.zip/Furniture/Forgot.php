<?php
  include 'dbconnect.php';
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;

  require 'phpmailer/src/Exception.php';
  require 'phpmailer/src/PHPMailer.php';
  require 'phpmailer/src/SMTP.php';

  if(isset($_POST['submit']))
  {
    $user_email = $_POST['user_email'];

    $sql = "SELECT * FROM `admin` WHERE `admin_email` = '$user_email'";
    $result = mysqli_query($conn , $sql);
    $row = mysqli_num_rows($result);
    if($row>=1)
    {
                    $data = mysqli_fetch_assoc($result);
                    $user_id = $data['admin_id'];
                    $code = mt_rand(1111,9999);
                    $sql = "UPDATE `admin` SET `verification` = '$code' WHERE `admin_id` = '$user_id'";
                    $result = mysqli_query($conn , $sql);

                    $mail = new PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'haiderb811@gmail.com';
                    $mail->Password = 'naytilecftbtaewl';
                    $mail->SMTPSecure = 'ssl';
                    $mail->Port = 465;

                    $mail->setFrom('haiderb811@gmail.com');

                    $mail->addAddress($_POST["user_email"]);
                    $mail->isHTML(true);

                    $mail->Subject = "Verification Code From GetRest";
                    $mail->Body = "This is your verification code : ".$code."";

                    $mail->send();
                    if($mail)
                    {
                        header("location:/furniture/code.php?uno=".$user_id."&type=admin");
                    }
                  }
                  else
                  {
                    $sql = "SELECT * FROM `users` WHERE `user_email` = '$user_email'";
                    $result = mysqli_query($conn , $sql);
                    $row = mysqli_num_rows($result);
                    if($row>=1)
                    {
                      $data = mysqli_fetch_assoc($result);
                    $user_id = $data['user_id'];
                    $code = mt_rand(1111,9999);
                    $sql = "UPDATE `users` SET `verification` = '$code' WHERE `user_id` = '$user_id'";
                    $result = mysqli_query($conn , $sql);

                    $mail = new PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'haiderb811@gmail.com';
                    $mail->Password = 'naytilecftbtaewl';
                    $mail->SMTPSecure = 'ssl';
                    $mail->Port = 465;

                    $mail->setFrom('haiderb811@gmail.com');

                    $mail->addAddress($_POST["user_email"]);
                    $mail->isHTML(true);

                    $mail->Subject = "Verification Code From GetRest";
                    $mail->Body = "This is your verification code : ".$code."";

                    $mail->send();
                    if($mail)
                    {
                        header("location:/furniture/code.php?uno=".$user_id."&type=users");
                    }
                    }
                  }
  }


?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Forgot</title>
  <link rel="stylesheet" href="css_login.css">
<style>

.email22 {
margin-left: 39%;
margin-top: 2%;

}


.forgotsubmitbtn {
  margin-left: 44%;
  margin-top: 1%;
  
}
 



</style>
</head>

<body>
  
<h1 style="margin-left: 43%; margin-top: 4%; color: #007D69;">Forgot</h1>
<form action="/furniture/forgot.php" method="post">
<div class="email22">
<input type="email" name="user_email" placeholder="Email Address" style="width: 27%;">
</div>
<div class="forgotsubmitbtn">
<input type="submit" name="submit" value="submit" style="width: 10%;">
</form>
</div>