<?php
  include 'dbconnect.php';
  include 'admin_check_login.php';

  $cat_name = "";
  if(isset($_POST['add_cat']))
  {
    if(!empty($_POST['cat_name']))
    {
      $cat_name = $_POST['cat_name'];

      $sql = "SELECT * FROM `category` WHERE `category_name` = '$cat_name'";
      $result = mysqli_query($conn , $sql);
      $row = mysqli_num_rows($result);
      if($row<=0)
      {
        $sql = "INSERT INTO `category` (`category_name`)VALUES('$cat_name')";
        $result = mysqli_query($conn , $sql);
      }
    }
  }

  $null = false;
  $item_cat = $item_name = $item_desc = $item_price = $img1 = $img2 = $img3 = "";

  if(isset($_POST['add_item']))
  {
    if(empty($_POST['item_cat']))
    {
      $null = true;
    }
    else
    {
      $item_cat = $_POST['item_cat'];
    }

    if(empty($_POST['item_name']))
    {
      $null = true;
    }
    else
    {
      $item_name = $_POST['item_name'];
    }

    if(empty($_POST['item_desc']))
    {
      $null = true;
    }
    else
    {
      $item_desc = $_POST['item_desc'];
    }

    if(empty($_POST['item_price']))
    {
      $null = true;
    }
    else
    {
      $item_price = $_POST['item_price'];
    }

    if($null == false)
    {
      $img1 = $_FILES["img1"]["name"];
      $img1_temp = $_FILES["img1"]["tmp_name"];
      $folder1 = "C:/xampp/htdocs/furniture/".$img1;

      $img2 = $_FILES["img2"]["name"];
      $img2_temp = $_FILES["img2"]["tmp_name"];
      $folder2 = "C:/xampp/htdocs/furniture/".$img2;

      $img3 = $_FILES["img3"]["name"];
      $img3_temp = $_FILES["img3"]["tmp_name"];
      $folder3 = "C:/xampp/htdocs/furniture/".$img3;

      $sql = "SELECT * FROM `category` WHERE `category_name` = '$item_cat'";
      $result = mysqli_query($conn , $sql);
      $row = mysqli_num_rows($result);
      if($row>=1)
      {
        $data = mysqli_fetch_assoc($result);
        $cat_id = $data['category_id'];

        $query = "SELECT * FROM `category_items` WHERE `item_name` = '$item_name' AND `item_price` = '$item_price' AND `item_desc` = '$item_desc'";
        $res = mysqli_query($conn , $query);
        $row = mysqli_num_rows($res);
        if($row<1)
        {
          $sql1 = "INSERT INTO `category_items` (`category_id` , `item_name` , `item_price` , `item_pic` , `item_desc`)
             VALUES ('$cat_id' , '$item_name' , '$item_price' , '$img1' , '$item_desc')";
          $result1 = mysqli_query($conn , $sql1);

          if($result1)
          {
            $sql2 = "SELECT * FROM `category_items` WHERE `category_id` = '$cat_id' AND `item_name` = '$item_name'";
            $result2 = mysqli_query($conn , $sql2);
            $data = mysqli_fetch_assoc($result2);
            $item_id = $data['item_id'];

            $sql3 = "INSERT INTO `item_images` (`item_id` , `item_pic`) VALUES ('$item_id' , '$img2')";
            $result3 = mysqli_query($conn , $sql3);
            $sql4 = "INSERT INTO `item_images` (`item_id` , `item_pic`) VALUES ('$item_id' , '$img3')";
            $result4 = mysqli_query($conn , $sql4);

            move_uploaded_file($img1_temp , $folder1);
            move_uploaded_file($img2_temp , $folder2);
            move_uploaded_file($img3_temp , $folder3);
          }
        }

      }

      
    }

  }

  $sql = "SELECT * FROM `category`";
  $result = mysqli_query($conn , $sql);
  $row = mysqli_num_rows($result);
?>


<html><head>
    <title>Admin</title>
  
  
  
    <link rel="stylesheet" href="css.css">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
 <style>
.itemcon1 {
border: 2px solid #007D69;
 width: 300px;
 height: 430px;
  margin-top:70px;
  margin-right:1120px;
}

.itemcon12 {
 border: 2px solid #007D69;
 width: 300px;
 height: 170px;
 margin-left: 39%;
 margin-top: 5%;
}

.main12{
  width:90%;
  margin:auto;
  position:relative;
  top:-20px;
  height:<?php if($row<=4){echo'5px;';}else{echo'150px;';} ?>;
}
.cat1{
  border:1px solid #007D69;
  width:200px;
  height:80px;
  float:left;
  /* padding:30px; */
  margin-left:68px;
  margin-bottom:30px;
}

.cat1 h1{
  text-align:center;
  margin-top:7px;
}

.cat1 button{
  margin-top:6px;
  
}

.categorydelete1 {
  border: 1px solid #007D69;
  width: 200px;
 height: 80px;
 margin-left: 5%;
 
}

.categorydelete2 {
  border: 1px solid #007D69;
  width: 200px;
 height: 80px;
 margin-left: 29%;
 margin-top: -6.2%;
 
}

.categorydelete3 {
  border: 1px solid #007D69;
  width: 200px;
 height: 80px;
 margin-left: 55%;
 margin-top: -6.2%;
}

.categorydelete4 {
  border: 1px solid #007D69;
  width: 200px;
 height: 80px;
 margin-left: 80%;
 margin-top: -6.2%;
}

.dropdown-content1 {
  display: none;
  position: absolute;
  background-color: #e2e1e1;
  box-shadow: 0 4px 1px rgba(173, 107, 107, 0.1);
  z-index: 1;
  margin-left: 16%;
}
.dropdown-content1 a {
  display: block;
  padding: 9px;
  color: #007D69;
}


/* Show dropdown on hover */
nav li:hover .dropdown-content1 {
  display: block;
}
</style>

  
  </head>
  <body>
  <script src="js.js"></script>
      
  
  
  <div class="background1">
   
  <header>

    <div class="logo1">
            
        <p>
            </p><h2>
                GetRest
            </h2>
        <p></p>
      </div>
      <!-- Update class names in the HTML -->
      <p class="aboutheader">
      <table class="nav-table">
        <nav>
          <ul>
            <?php echo'<li><a href="admin_furniture.php?ano='.$admin_id.'" target="_self"style="color: black;">Add New Category</a></li>';?>
            

            <?php echo'<li> <a href="category_admin.php?cid=1&ano='.$admin_id.'" target="_self"style="color: black;">Categories</a>';?>
              <!-- Dropdown content -->
              <div class="dropdown-content1">
                  <?php
                    $sql = "SELECT * FROM `category`";
                    $result = mysqli_query($conn , $sql);
                    while($data = mysqli_fetch_assoc($result))
                    {
                      $category_id = $data['category_id'];
                      $category_name = $data['category_name'];
                      echo '<a href="category_admin.php?cid='.$category_id.'&ano='.$admin_id.'" style="color: black;">'.$category_name.'</a>';
                    }
                  
              echo'<li><a href="order.php?ano='.$admin_id.'" target="_self"style="color: black;">Orders</a></li>';?>
              </div>
            </li>
            
           
            <?php echo'<li><a href="multiple.php?ano='.$admin_id.'" target="_self"style="color: black;">multiple item orders</a></li>';?>
            <?php echo'<li><a href="admin_logout.php?ano='.$admin_id.'" target="_self"style="color: black;">Logout</a></li>';?>
          </ul>
        </nav>
      </table>
    </p>
    </header>
    <p class="headertext">
        <center><p style="color: white;font-size: 40px;">Admin</p></center>
    </p>
  </div>





  

  <div class="itemcon12">
    <br>
    <h3 style="margin-left: 26%;">Category Name</h3><br>
    <?php echo'<form action="/furniture/admin_furniture.php?ano='.$admin_id.'" method="post">';?>
                  <input type="text" name="cat_name" style="margin-left: 0%;color:black;height: 25px;px;border:1px solid black;width:250px;padding-left:5px;"><br><br>
                  <button type="submit" name="add_cat" style="width: 40%; margin-left: 0%;  background-color: #007D69;position:relative;top:-15px;">Submit</button>
    </form>
  </div>
<br><br><br>

  <?php
    $sql = "SELECT * FROM `category`";
    $result = mysqli_query($conn , $sql);
    echo '<div class="main12">';
    while($data = mysqli_fetch_assoc($result))
    {
      $category_name = $data['category_name'];
      $category_id   = $data['category_id'];
      echo '<div class="cat1">
        <h1>'.$category_name.'</h1>
        <a href="/furniture/delete_category.php?ano='.$admin_id.'&cid='.$category_id.'"><button type="submit">Delete</button></a>
      </div>';
    }
    echo'</div>';
  ?>


              <br>
                <?php echo'<form action="/furniture/admin_furniture.php?ano='.$admin_id.'" method="post" enctype="multipart/form-data">';?>
                <div class="itemcon1"><br>
                  <h3 style="margin-left: 27%;">Item Category</h3>
                  <input type="text" name="item_cat" style="margin-left: 21%;width:165px;border:1px solid black;color:black;position:relative;right:0px;" required="required">
                
                  <br><br>
                  <h3 style="margin-left: 31%;">Item Name</h3>
                  <input type="text" name="item_name" style="margin-left: 21%;width:165px;border:1px solid black;color:black;position:relative;right:0px;" required="required">
                  <br><br>
                  <h3 style="margin-left: 27%;">Item Description</h3>
                  
                  <textarea id="message" name="item_desc" rows="1.5" required style="margin-left: 21%; width: 55%;"></textarea>
                 <br><br>
                  <h3 style="margin-left: 31%;">Item Price</h3>
                  <input type="number" name="item_price" style="margin-left: 21%;width:165px;border:1px solid black;color:black;position:relative;right:0px;" required="required">

                  <br><br>
                  <h3 style="margin-left: 31%;">Item Images</h3>
                  <input type="file" name="img1" style="margin-left: 21%;color:black;" required="required">
                  <input type="file" name="img2" style="margin-left: 21%;margin-top:5px;color:black;" required="required">
                  <input type="file" name="img3" style="margin-left: 21%;margin-top:5px;color:black;" required="required">
                  
                  <br><br>
                  <button type="submit" name="add_item" style="width: 40%; margin-left: 90px;  background-color: #007D69;position:relative;top:0px;">Submit</button>
                </div>
                </form>




  <br><br><br><br><br><br>


<!-- footer -->
<footer>
  <div class="row">
    <div class="col">
      <h2 style="color: #007D69;">GetRest</h2>
      <p>
        Ferozpur Road Lahore
        <br><br>
        haiderb811@gmail.com
        <br><br>
        03310155706
      </p>
    </div>
    <div style="margin-left: %;">
  <div class="col"> 
   <h2>Office</h2>
   <p>Ferozpur Road</p>
   <p>Kalma Chowk, Lahore</p>
   <p>54600, Pakistan</p>
   <p class="email-id">haiderb811@gmail.com</p>
   <h4>+92 - 03310155706</h4>

  </div>
</div>

  <div class="col">
    <h2>Links</h2>
    
    <ul>
    <li><a href="homef.php">Home</a></li>
       <li><a href="Aboutf.php">About</a></li>
        <li><a href="productf.php">Product </a></li>
        <li><a href="cardf.php">Cart </a></li>
        <li><a href="contactf.php">Contact </a></li>
    </ul>
  </div>

  <div class="col">
<h2>NewsLette</h2>
<form>
  <div class="footer-section">
  <form action="#" method="post">
    <input type="email" name="email" placeholder="Your Email" style="color: black;">
    <button type="submit">Subscribe</button>
</form>

  </div>
  
  </div>
  </div>
</footer>
</div>
</div>

</body>