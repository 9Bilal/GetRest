-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2024 at 05:45 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `furniture`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(10) NOT NULL,
  `admin_email` varchar(100) NOT NULL,
  `admin_pass` varchar(255) NOT NULL,
  `verification` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_email`, `admin_pass`, `verification`) VALUES
(1, 'admin@gmail.com', 'admin', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `category_id` int(10) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `item_price` int(20) NOT NULL,
  `item_pic` varchar(255) NOT NULL,
  `item_desc` varchar(255) NOT NULL,
  `quantity` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `item_id`, `category_id`, `item_name`, `item_price`, `item_pic`, `item_desc`, `quantity`) VALUES
(92, 2, 3, 1, 'Cresta Bed', 120000, 'bed2.jpg', ' Cresta Bed the fine line between contemporary and functional with a pop of white colour. The button tufted panel on the headboard brings an edge to its design. Two storage drawers at the base of this bed are an added advantage. The wooden frame is fitted', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'BED'),
(2, 'SOFA'),
(3, 'KIDS'),
(4, 'CHAIR');

-- --------------------------------------------------------

--
-- Table structure for table `category_items`
--

CREATE TABLE `category_items` (
  `item_id` int(10) NOT NULL,
  `category_id` int(10) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_price` int(10) NOT NULL,
  `item_pic` varchar(255) NOT NULL,
  `item_desc` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category_items`
--

INSERT INTO `category_items` (`item_id`, `category_id`, `item_name`, `item_price`, `item_pic`, `item_desc`) VALUES
(2, 1, 'Long Headboard Bed', 180000, 'bed3.jpg', ' Introducing the Long Headboard Bed, a perfect blend of modern minimalism and innovative design. With its laminated construction, stylish light brown and white shades, and unique features, the Long Headboard Bed offers a contemporary look that will instantly enhance the aesthetics of your bedroom. Let\'s explore the remarkable design and functionality that make our Mack Bed a must-have for those seeking a modern and space-saving solution.\n\nMaterial:  Metal Rod in Headboard and Lamination structure\n\nLong Headboard Bed Is a Floor Bed\n\nDimensions:\n\nTotal Length: 6.7 ft\nTotal width: 6.08 ft\nTotal Height: 2.83 ft \nShelf: 6 Inches \nPlanks: 4 Inches\nSize: King Size Bed\n'),
(3, 1, 'Cresta Bed', 120000, 'bed2.jpg', ' Cresta Bed the fine line between contemporary and functional with a pop of white colour. The button tufted panel on the headboard brings an edge to its design. Two storage drawers at the base of this bed are an added advantage. The wooden frame is fitted with slats to amp up the comfort, so that your dreams are sweet and uninterrupted. \n\nBed Mattress Sizes:\n\nQueen - Size 1 = 5 feet by 6.5 feet\nQueen - Size 2 = 5.5 feet by 6.5 feet\nKing Size = 6 feet by 6.5 feet'),
(4, 1, 'Gomze Double Bed', 180000, 'bed.jpg', 'Gomze shines through with an upholstered finish and channel tufting. To add suave to your back and the bedroom pair this modern design made for the sweetest of dreams. This might be just what you need to sink in comfort!\n\n\nDimensions:\n\nHeadrest height 54 inches\n\nLength 83 inches\n\nWidth 70.5 inches\n\nBed Mattress Sizes:\n\nQueen - Size 1 = 5 feet by 6.5 feet\nQueen - Size 2 = 5.5 feet by 6.5 feet\nKing Size = 6 feet by 6.5 feet'),
(6, 1, 'Mocca Double Bed', 150000, 'bed4.jpg', 'The perfect mix of caramel and chocolate, the Mocca Double Bed fulfills your craving for both! It\'s an exceptionally crafted design that fit\'s in a modern bedroom with grace.\n\nDimensions:\nLength :    81\" \nWidth   :    62.5\'\' (Queen 1) 68.5\" (Queen 2) 74.5\'\' (King) \nHeadboard:       48\" \n\n\nBed Mattress Sizes:\n\nQueen - Size 1 = 5 feet by 6.5 feet\nQueen - Size 2 = 5.5 feet by 6.5 feet\nKing Size = 6 feet by 6.5 feet'),
(7, 1, 'Hauga Upholstered Bed', 99000, 'bed7.jpg', 'This Hauga upholstered bed frame brings warmth and softness into your bedroom. The durable two-toned fabric, the gently curved headboard and the piped edges create a classic expression you will enjoy for years.\nDimensions:\n\nHeadrest height 54 inches\n\nLength 83 inches\n\nWidth 70.5 inches\n\nBed Mattress Sizes:\n\nQueen - Size 1 = 5 feet by 6.5 feet\nQueen - Size 2 = 5.5 feet by 6.5 feet\nKing Size = 6 feet by 6.5 feet'),
(8, 1, 'Oyster Upholstered Bed', 190000, 'bed6.jpg', 'Oyster is a fine stage stealer for the lovers of minimal. The neat button tufting adds an aesthetically pleasing texture to the looks of it, giving it an ethereal appeal. Pair this beauty with matching bedside tables, dresser, and chest of drawers to create a pleasant bedroom set up of your own. \n\nBed Mattress Sizes:\n\nQueen - Size 1 = 5 feet by 6.5 feet\nQueen - Size 2 = 5.5 feet by 6.5 feet\nKing Size = 6.2 feet by 6.5 feet'),
(9, 1, 'Zimer Bed', 170000, 'bed9.jpg', 'Made with high-quality materials, this bed is designed to last for years to come. The sturdy frame is constructed from solid wood, ensuring stability and durability. The headboard and footboard feature a sleek and modern design, making it the perfect canter piece for any bedroom. \n                            \nBed Mattress Sizes:\n\nQueen - Size 1 = 5.2 feet by 6.5 feet\nQueen - Size 2 = 5.5 feet by 6.5 feet\nKing Size = 6.3 feet by 6.5 feet'),
(10, 1, 'Lily Bed', 144000, 'bed8.jpg', 'Blue is an excellent choice for minimalist spaces as it seamlessly blends with wood, steel, and glass. For some white wall paint colours can be a Blue colour, so one can add touches of colour to brighten the space. 6ft headboard, with a plain base.\nHand pleated\nVertical line pattern headboard\nAvailable in a variety of different colours and fabrics, please see our fabric samples page for full selection Fabric Samples – The Luxury Bed.\n\nDimensions:\nLength :    211cm\" \nWidth   :    114cm\" \n\nBed Mattress Sizes:\n\nQueen - Size 1 = 5 feet by 6.5 feet\nQueen - Size 2 = 5.5 feet by 6.5 feet\nKing Size = 6 feet by 6.5 feet'),
(18, 3, 'Bugge Bed', 160000, 'kids1.jpg', 'The Bugge Bed, a hallmark of minimalist design by architect Knudsen Berg Hindenes, epitomizes the blend of function and form. With its clean lines and modern aesthetic, the bed is crafted to serve as a focal point in any contemporary bedroom.Twin (Single):\n\nWidth: 39 inches (99 cm)\nLength: 75 inches (191 cm)\nTwin XL:\n\nWidth: 39 inches (99 cm)\nLength: 80 inches (203 cm)\nFull (Double):\n\nWidth: 54 inches (137 cm)\nLength: 75 inches (191 cm)\nQueen:\n\nWidth: 60 inches (152 cm)\nLength: 80 inches (203 cm)\nKing:\n\nWidth: 76 inches (193 cm)\nLength: 80 inches (203 cm)'),
(19, 3, 'Essential Kids\' Bedroom', 70000, 'kids2.jpg', 'The Essential Kids\' Bedroom is designed to be a practical, fun, and comfortable space tailored to the needs of children. It combines functionality with playful elements to create an environment that fosters creativity, learning, and relaxation.\n\nKey Features:\nFurniture:\n\nBed: A sturdy and comfortable bed sized appropriately for the child’s age, such as a twin or full bed. Bunk beds or loft beds can be used for shared rooms or to save space.\nStorage: Plenty of storage options, including dressers, closets, shelves, and under-bed storage, to keep clothes, toys, and books organized.\nDesk and Chair: A dedicated workspace with a child-sized desk and ergonomic chair for homework and creative activities.\nDesign and Decor:\n\nTheme: Choose a fun and engaging theme that reflects the child’s interests, such as animals, space, sports, or a favorite cartoon character.\nColor Scheme: Bright and cheerful colors to stimulate imagination and create a happy atmosphere.'),
(20, 3, 'JOY Kids Sofa', 22000, 'kids3.jfif', 'The JOY Kids Sofa is a delightful addition to any child\'s room, blending comfort, durability, and playful design. Perfectly scaled for little ones, this sofa provides a cozy spot for reading, relaxing, and imaginative play.\n\nKey Features:\nDesign and Aesthetics:\n\nChild-Friendly Design: The JOY Kids Sofa features a fun and inviting design that appeals to children, often incorporating bright colors, whimsical patterns, and cute shapes.\nVersatile Styles: Available in various styles and themes to match different room decors, from modern and sleek to playful and themed.\nComfort and Size:\n\nPerfectly Sized: Designed to fit children comfortably, with dimensions suitable for toddlers and young kids.\nSoft Upholstery: Covered in soft, durable fabrics that are gentle on the skin and comfortable for long periods of sitting.\nConstruction and Durability:\n\nSturdy Frame: Built with a strong frame to withstand the active use typical of children\'s furniture.\n'),
(21, 3, 'Cozy Children\'s Chair', 10000, 'kids4.jpg', ' The Cozy Children\'s Chair is the perfect blend of comfort, style, and durability, designed to offer a snug and inviting seating option for kids. Ideal for reading, relaxing, or engaging in creative activities, this chair adds a touch of warmth and coziness to any child\'s room.  Key Features: Design and Aesthetics:  Child-Friendly Design: The Cozy Children\'s Chair features an appealing, child-friendly design with playful shapes, vibrant colors, and fun patterns that attract kids. Variety of Styles: Available in different styles to match various room themes, from classic and elegant to modern and whimsical. Comfort and Size:  Overall Dimensions:  Width: 20 to 24 inches (51 to 61 cm) Depth: 18 to 22 inches (46 to 56 cm) Height: 22 to 26 inches (56 to 66 cm) Seat Dimensions:  Seat Width: 12 to 16 inches (30 to 41 cm) Seat Depth: 12 to 16 inches (30 to 41 cm) Seat Height (from floor): 10 to 14 inches (25 to 36 cm)'),
(22, 3, 'Chelsea Kids', 70000, 'kids5.jpg', '  Our range of luxury kids beds have been amazingly popular in store & we are proud to now release them ONLINE!  All kids beds come with a FREE Rio Mattress In the same size as the bed you have selected.  Dimensions Single – Width 105cm & Length 205cm Small double – Width 130cm & Length 205cm All measurements are as accurate as can be but please do allow tolerances as all beds are bespoke, handmade individually to order.  Headboard height: 50 inches from the floor up.'),
(23, 3, 'Dolly PlayHouse Bed', 120000, 'kids6.jpg', 'Dolly Playhouse is a luxury kid bed specially made to ensure that kids have the ultimate fun in their bedroom. Inspired by the infamous dollhouses, the Dolly Playhouse bed is a modern version of a kid\'s playhouse, specially made for little ones who want their own little house adventure and have a full space to themselves.             DIMENSIONS                    Height: 291 cm | 115\"       Width: 254 cm | 100\"        Depth: 240 cm | 94\"'),
(24, 3, 'Hideout Bed', 90000, 'kids7.jfif', 'One bed frame and many possibilities! The Hideout bed makes fantasies and fairy tales come alive with its fun tent-style design. Made of solid oak and engineered board, the bed is strong and beautiful to support every adventure little and big that your child comes up with. A firm mattress, soft pillow and smooth linens will turn night time cosy and comfy.Width: 117 cm Depth: 216.7 cm Height: 130 cm Weight: 76 kg'),
(25, 3, 'Kids Tent Bedroom Cabin', 40000, 'kids8.jpg', 'The Kids Tent Bedroom Cabin is an imaginative and cozy addition to any child’s bedroom, offering a unique space for play, relaxation, and sleep. This tent cabin combines the charm of a traditional camping tent with the comfort and safety of indoor furniture, creating a magical retreat for kids.Small Size:\n\nWidth: 36 inches (91 cm)\nDepth: 36 inches (91 cm)\nHeight: 40 inches (102 cm)\nMedium Size:\n\nWidth: 48 inches (122 cm)\nDepth: 48 inches (122 cm)\nHeight: 50 inches (127 cm)\nLarge Size:\n\nWidth: 60 inches (152 cm)\nDepth: 60 inches (152 cm)\nHeight: 60 inches (152 cm)'),
(26, 4, 'Hayward Lounge Chair', 18000, 'chair1.jpg', 'The Hayward Lounge Chair cuts a classic figure: mid-century modern style, solid oak frame, and soft upholstery around high-density foam make for a white accent armchair that will see you through many seasons — and look great doing it. A wonderful spot to lounge.\r\nDIMENSIONS (MM):\r\nH: 800 \r\nD: 830 \r\nW: 730 \r\nSEAT HEIGHT: 410'),
(27, 4, 'Modern Chair', 40000, 'chair2a.jpg', 'The Modern Chair is a versatile and stylish piece of furniture designed to enhance the aesthetic and functionality of various spaces. Its contemporary design, comfort, and adaptability make it an ideal choice for a wide range of settings.\nFeatured Velvet\nComfy Thick Cushion\nMetal Legs.'),
(28, 4, 'Boucle Occasional Chair', 22000, 'chair33.jpg', 'The Boucle Occasional Chair is a luxurious and stylish piece of furniture known for its distinctive boucle fabric and elegant design. It serves as a sophisticated addition to various spaces, providing comfort and enhancing the aesthetic appeal of the room.\r\n\r\nWidth: 28 to 32 inches (71 to 81 cm)\r\nDepth: 30 to 34 inches (76 to 86 cm)\r\nHeight: 30 to 36 inches (76 to 91 cm)\r\nSeat Height: 16 to 18 inches (41 to 46 cm)'),
(29, 4, 'Helen Considered Chair', 10000, 'chair4.jpg', 'The \"Helen Considered Chair\" is a modern and sophisticated piece of furniture designed to blend elegance with functionality. Its sleek lines and contemporary silhouette make it a versatile addition to various living spaces, from dining rooms to home offices and lounges.\r\nWidth: Typically ranges from 18 inches (46 cm) to 24 inches (61 cm) for the seat width.\r\nDepth: Generally falls between 18 inches (46 cm) to 24 inches (61 cm) for the seat depth.\r\nHeight: Chairs usually range from 30 inches (76 cm) to 40 inches (102 cm) in total height, depending on the style and backrest height.\r\nSeat Height: The height from the floor to the top of the seat typically varies from 16 inches (41 cm) to 18 inches (46 cm).'),
(30, 4, 'Clingy Lover Chair', 10000, 'chair5a.jpg', 'The Clingy Lover Chair is a unique and playful piece of furniture designed to evoke a sense of intimacy and comfort, resembling a chair that wraps around its occupant in a warm embrace.Design and Aesthetics:  Embracing Design: The Clingy Lover Chair features a distinctive design that envelops the sitter, creating a cocoon-like feeling of security and comfort. Curved Shape: Often characterized by curved lines and contours that mimic the shape of a hug, enhancing its visual appeal and ergonomic support. Modern and Quirky: Combines modern aesthetics with a touch of whimsy, making it a conversation starter and focal point in any room.'),
(31, 4, 'Cream Velvet Accent Chair ', 15000, 'chair6.jpeg', 'The Cream Velvet Accent Chair exudes elegance and sophistication with its luxurious velvet upholstery and stylish design. This chair serves as a striking focal point in any room, combining comfort with timeless aesthetics.\r\n Overall Dimensions: \r\nWidth: Approximately 28 to 32 inches (71 to 81 cm) \r\nDepth: Approximately 30 to 34 inches (76 to 86 cm) \r\nHeight: Approximately 30 to 36 inches (76 to 91 cm) Seat Dimensions: \r\n Seat Width: Approximately 20 to 24 inches (51 to 61 cm) \r\nSeat Depth: Approximately 20 to 24 inches (51 to 61 cm) \r\nSeat Height: Approximately 18 to 20 inches (46 to 51 cm) from the floor'),
(32, 4, 'Christopher Club Chair', 20000, 'chair17.jpg', 'The Christopher Leather Club Chair pairs mid-century forms with traditional craftsmanship to create unmatched style; a stunning choice for any space.\r\n\r\nShown In	Tan\r\nMaterial Detail	Top Grain Leather\r\nLeg Finish	Black\r\nDimensions	26.8\"w 33\"d 33.5\"h\r\nArm Height	24\"h\r\nSeat Height	19\"h'),
(33, 4, 'Reading Chair', 13000, 'chair8.jpg', 'A reading chair is specifically designed to provide comfort and support for extended periods of reading or relaxing. Here\'s a detailed description of a typical reading chair:\r\nDesign and Aesthetics:\r\n\r\nComfortable Seating: Designed with a focus on comfort, featuring ample cushioning and ergonomic support.\r\nUpholstery: Often upholstered in soft and durable fabrics like linen, cotton, or velvet, providing a cozy feel.\r\nClassic or Contemporary: Available in various designs, from classic wingback chairs to modern recliners, to suit different decor styles.\r\nSize and Dimensions:\r\n\r\nWidth: Typically ranges from 28 to 36 inches (71 to 91 cm), providing enough space for comfortable seating.\r\nDepth: Generally between 30 to 36 inches (76 to 91 cm), offering room to sit back and relax.\r\nHeight: Often around 36 to 40 inches (91 to 102 cm) tall, providing adequate back support.'),
(36, 2, 'Introspect Modern Sofa', 60000, 'sofa1.jpg\r\n', 'Introspect sofa - possibly the most comfortable couch in the world - is a classic mid-century modern design with high-density foam cushions, Introspect is the perfect small apartment sofa, or centerpiece of a spacious East Hampton home.\n\nTry Introspect in person.\n\nIntrospect is a luxury sofa that is built to last with a solid wood frame and durable, easy-to-clean (dish soap and warm water).\n\nConsidered our most comfortable sofa\nPerfect for small living rooms\nGuaranteed to fit into your apartment\nPet-friendly and kid-friendly\nMedium seat height; medium seat depth'),
(37, 2, 'Eden Sofa', 70000, 'sofa2.jpg', 'Eden Modular Fabric Sofa Group. Large modular sofa pieces which can be customised to suit your room. The Eden corner group is not be rivalled in comfort, style and deep seated luxury. Fibre filled for that super luxurious seating experience it is a truly magnificent sofa. Scatter cushions are exclusive in price. Brand: GS Premier Collection\n\nDisplay: \nWebsite Exclusive\n\nRecommendations: Expert Choice\nCategory: Sofas\nSize: Available In Multiple Sizes\nStyle: Modern Designs\nTradtional Comfort\nMaterial: Fabric\nSelect Size: RHF Chaise Unit'),
(38, 2, 'Apollo Combo Corner Sofa', 99000, 'sofa3.jpg', 'Introducing the Apollo Combo Corner Sofa, where comfort meets innovation in a sleek and modern design. Crafted with meticulous attention to detail and superior craftsmanship, this corner sofa bed is the perfect combination of style, functionality, and versatility.Width: 265 cm x 331 cm\n\nHeight: 79 cm / 97 cm\n\nDepth: 105 cm\n\nSleeping area: 126 cm x 185 cm\n\nSeat Depth: 57 cm Weight:	209 kg\nDelivery Time:	2-6 weeks\nWarranty:	2 Years\nParts:	4'),
(39, 2, 'U-Shape Sofa', 150000, 'sofa4.jpg', 'The London U shape sofa is the perfect piece for your living space, from its wide cushioned seats to its luxury chenille upholstery, it is a stunning piece of modern design. The removable footstools give you a choice to transform into the right or the left corner sofa. We have intentionally chosen this fabulous collection because of its superb build quality, adjustable design, and unbeatable price. KEY FEATURES:\n\nLuxury Chenille Fabric\n9 Scatter Back Cushions\nRemovable/Washable All Covers\nPolished Chrome Feet\nMovable Footstools for Multi-Purpose Use\nAssembly Required\nDIMENSIONS:\n\nWidth: 309cm\nLength: 189cm\nHeight: 72cm\nOverall Height: 84cm\nFloor to Top of The Seat 47 cm\nSeat Depth: 57/69cm'),
(40, 2, 'Pebble Cream Fabric Sofa', 99000, 'sofa5.jpg', 'Snuggle up by the fireside with the Pebble Cream Teddy Bear Fabric 2 Seater Sofa. Offering an invitation to pure relaxation with its enveloping shape and cosy, sherpa-like, teddy bear fabric, the Pebble lures you in with its welcoming aura and homely features. Its curvaceous, mod-style silhouette makes a statement and ensures that this piece will stand proud in any setting; whilst a high resilient foam fills the seat interior to deliver a firm yet supportive seating experience. Size\nSeats 2\nColour\nCream\nMaterial\nFabric\nSizes Are Approximate\nYes\nSome Assembly May Be Required\nYes'),
(41, 2, '2 Seater Sofa Set', 199000, 'sofa6.jfif', 'Hand-built frames with hand-finished upholstery. The back is formed with flex foam and a poly-fiber blend.\nKeekar wood frame and engineered hardwood frame with reinforced joinery. This sofa can have a tailored valance and looks very smart. Wooden legs with polish finish\nMaterial Used:\n\nKeekar Frame, Plywood, and Flex Foam'),
(42, 2, 'Sight Unseen Wooden Sofa', 50000, 'sofa7.jpg', '..............'),
(43, 2, 'Wakefit Sofa', 100000, 'sofa8.jpg', 'The Wakefit Sofa is designed to provide both style and comfort to your living space. Combining contemporary design with practical functionality, this sofa is a perfect addition to any home.\nIntrospect is a luxury sofa that is built to last with a solid wood frame and durable, easy-to-clean (dish soap and warm water).\n\nConsidered our most comfortable sofa\nPerfect for small living rooms\nGuaranteed to fit into your apartment\nPet-friendly and kid-friendly\nMedium seat height; medium seat depth');

-- --------------------------------------------------------

--
-- Table structure for table `item_images`
--

CREATE TABLE `item_images` (
  `id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `item_pic` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item_images`
--

INSERT INTO `item_images` (`id`, `item_id`, `item_pic`) VALUES
(0, 36, 'sofa1a.jpg'),
(1, 2, 'bed3a.jpg'),
(2, 2, 'bed3a1.jpg'),
(3, 3, 'bed2a.jpg'),
(4, 3, 'bed2a1.jpg'),
(5, 4, 'beda1.jpg\r\n'),
(6, 4, 'beda2.jpg'),
(7, 6, 'bed4a.jpg'),
(8, 6, 'bed4a1.jpg'),
(9, 7, 'bed7a.jpg\r\n'),
(10, 7, 'bed7a1.jpg'),
(11, 8, 'bed6a.jpg'),
(12, 8, 'bed6a1.jpg'),
(13, 9, 'bed9a.jpg'),
(14, 9, 'bed9a1.jpg'),
(17, 11, 'sofa2a.jpg'),
(18, 11, 'sofa2a1.png'),
(19, 12, 'sofa3a.jpg'),
(22, 13, 'soda4a.png'),
(23, 14, 'sofa5a.jpg'),
(24, 14, 'sofa5a1.jpg\r\n'),
(25, 15, 'sofa6a.jpg'),
(26, 15, 'sofa6a1.jpg'),
(27, 16, 'sofa7a.jpeg'),
(28, 16, 'sofa7a1.jpeg'),
(29, 17, 'sofa8a.jpg'),
(30, 18, 'kids1a.jpg'),
(31, 18, 'kids1a1.jpg'),
(33, 19, 'kids2a.jpg'),
(34, 19, 'kids2a1.jpg'),
(39, 20, 'kids3a11.jpg\r\n'),
(40, 20, 'kids3a12.jpg'),
(41, 21, 'kids4a.jpg'),
(42, 21, 'kids4a1.jpg'),
(43, 22, 'kids5a.jpg'),
(44, 22, 'kids5a1.jpg'),
(45, 23, 'kids6a.jpg'),
(46, 23, 'kids6a3.jpg\r\n'),
(47, 24, 'kids7a2.jfif'),
(48, 24, 'kids7a3.jfif'),
(49, 25, 'kids8a.jpg'),
(50, 25, 'kids8a1.jpg'),
(51, 26, 'chair1a.avif'),
(52, 26, 'chair1a1.avif'),
(53, 27, 'chair2a2.jpg'),
(54, 28, 'chair3a1.jpg'),
(55, 28, 'chair3a2.jpg\r\n'),
(56, 29, 'chair4a.jpg'),
(57, 29, 'chair4a1.jpg'),
(58, 30, 'chair5a1.jpg'),
(59, 30, 'chair5a2.jpg\r\n'),
(60, 31, 'chair6a.jpeg'),
(61, 31, 'chair6a1.jpeg'),
(62, 32, 'chair7a.jpg'),
(63, 32, 'chair7a1.jpg'),
(64, 33, 'chair8a.jpg'),
(65, 33, 'chair8a1.jpg'),
(66, 34, 'download (1).jpg'),
(67, 34, 'download (2).jpg'),
(73, 36, 'sofa1a2.jpg'),
(74, 37, 'sofa2a.jpg'),
(75, 37, 'sofa2a1.png'),
(76, 38, 'sofa3a.jpg'),
(77, 39, 'sofa4a.png'),
(78, 40, 'sofa5a.jpg'),
(79, 40, 'sofa5a1.jpg'),
(80, 41, 'sofa6a.jpg'),
(81, 41, 'sofa6a1.jpg'),
(82, 42, 'sofa7a.jpeg'),
(83, 42, 'sofa7a1.jpeg'),
(84, 43, 'sofa8a.jpg'),
(85, 44, 'WhatsApp Image 2024-06-03 at 12.52.24 AM.jpeg'),
(86, 44, 'WhatsApp_Image_2024-06-03_at_12.52.24_AM-removebg.png'),
(87, 45, '99.jpg'),
(88, 45, '98.jpg'),
(89, 46, 'WhatsApp Image 2024-06-03 at 12.52.24 AM.jpeg'),
(90, 46, 'WhatsApp_Image_2024-06-03_at_12.52.24_AM-removebg.png'),
(91, 47, '99.jpg'),
(92, 47, '98.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `name`, `email`, `city`, `message`) VALUES
(1, '', '', '', ''),
(2, '1111111', 'haiderb811@gmail.com', 'multan', 'wwwwwwwwww'),
(3, '1111111', 'haiderb811@gmail.com', 'multan', 'wwwwwwwwww'),
(4, 'qqqqqqqqqqqqqqqqqqqqq', 'haiderb811@gmail.com', 'karachi', 'qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq'),
(5, 'Bilal Haider', 'haiderb811@gmail.com', 'lahore', 'wwwwwwwwwwwwwww'),
(6, 'Bilal Haider', 'haiderb811@gmail.com', 'karachi', 'aaaaaaaaaaaaaa'),
(7, 'qqqqqqqqqqqqqqqqqqqqq', 'haiderb811@gmail.com', 'karachi', 'qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq'),
(8, 'Bilal Haider', 'haiderb811@gmail.com', 'karachi', 'kk'),
(9, 'Bilal Haider', 'haiderb811@gmail.com', 'karachi', 'jj');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `address` varchar(300) NOT NULL,
  `user_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(500) NOT NULL,
  `fabric` varchar(255) NOT NULL,
  `polish` varchar(255) NOT NULL,
  `comment` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `city`, `zip`, `address`, `user_id`, `cat_id`, `item_id`, `price`, `description`, `fabric`, `polish`, `comment`) VALUES
(70, 'Bilal Haider', 'Chakwal', '9999', 'xcvbn', 2, 1, 6, 0, '', '', '', ''),
(71, 'Bilal Haider', 'lahore', '222', '122', 2, 1, 6, 0, '', '', '', ''),
(72, 'Bilal Haider', 'lahore', '222', '122', 2, 1, 6, 0, '', '', '', ''),
(75, 'abc def', 'lahore', '222', '122', 2, 1, 2, 0, '', '', '', ''),
(78, 'Bilal Haider', 'Chakwal', '9999', 'xcvbn', 2, 1, 2, 0, '', '', '', ''),
(79, 'Bilal Haider', 'lahore', '222', '122', 2, 1, 6, 0, '', '', '', ''),
(80, 'Bilal Haider', 'Chakwal', '9999', 'xcvbn', 2, 1, 7, 99000, 'This Hauga upholstered bed frame brings warmth and softness into your bedroom. The durable two-toned fabric, the gently curved headboard and the piped edges create a classic expression you will enjoy for years.\nDimensions:\n\nHeadrest height 54 inches\n\nLength 83 inches\n\nWidth 70.5 inches\n\nBed Mattress Sizes:\n\nQueen - Size 1 = 5 feet by 6.5 feet\nQueen - Size 2 = 5.5 feet by 6.5 feet\nKing Size = 6 feet by 6.5 feet', '', '', ''),
(81, 'Bilal Haider', 'Chakwal', '9999', 'xcvbn', 2, 3, 18, 160000, 'The Bugge Bed, a hallmark of minimalist design by architect Knudsen Berg Hindenes, epitomizes the blend of function and form. With its clean lines and modern aesthetic, the bed is crafted to serve as a focal point in any contemporary bedroom.Twin (Single):\n\nWidth: 39 inches (99 cm)\nLength: 75 inches (191 cm)\nTwin XL:\n\nWidth: 39 inches (99 cm)\nLength: 80 inches (203 cm)\nFull (Double):\n\nWidth: 54 inches (137 cm)\nLength: 75 inches (191 cm)\nQueen:\n\nWidth: 60 inches (152 cm)\nLength: 80 inches (203 cm', '', '', ''),
(82, 'Bilal Haider', 'lahore', '222', '122', 2, 3, 19, 0, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `subscribe`
--

CREATE TABLE `subscribe` (
  `email` varchar(255) NOT NULL,
  `id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscribe`
--

INSERT INTO `subscribe` (`email`, `id`) VALUES
('user@gmail.com', 1),
('user@gmail.com', 2),
('zzzzzzzz@gmail.com', 3),
('sohaib@gmail.com', 4),
('ssss@gmail.com', 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp(),
  `verification` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_email`, `user_pass`, `timestamp`, `verification`) VALUES
(1, 'abc@gmail.com', 'user', '2024-04-07 15:20:14', 0),
(2, 'user@gmail.com', 'user', '2024-04-07 15:57:01', 0),
(3, 'bilal1@gmail.com', 'user', '2024-04-08 06:07:02', 0),
(4, 'sohaib@gmail.com', 'user', '2024-04-27 08:11:21', 0),
(5, 'sohaibbb@gmail.com', 'user', '2024-04-27 10:24:35', 0),
(6, 'sohaib1@gmail.com', 'user', '2024-04-27 10:30:24', 0),
(7, 'euwyrique', 'user', '2024-04-27 10:32:41', 0),
(8, 'ahtisham@gmail.com', 'user', '2024-06-02 23:25:22', 0),
(9, 'asadda@gmail.com', 'user', '2024-06-05 21:14:49', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `category_items`
--
ALTER TABLE `category_items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `item_images`
--
ALTER TABLE `item_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribe`
--
ALTER TABLE `subscribe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `category_items`
--
ALTER TABLE `category_items`
  MODIFY `item_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `item_images`
--
ALTER TABLE `item_images`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `subscribe`
--
ALTER TABLE `subscribe`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
